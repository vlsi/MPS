/*
 * Copyright 2000-2009 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.cvsSupport2.errorHandling;

import com.intellij.openapi.vcs.VcsException;

import java.util.Collection;

/**
 * author: lesya
 */
public class CvsException extends VcsException{
  private final String myCvsRoot;
  public CvsException(String message, String cvsRoot) {
    super(message);
    myCvsRoot = cvsRoot;
  }

  public CvsException(Throwable throwable, String cvsRoot) {
    super(throwable);
    myCvsRoot = cvsRoot;
  }

  public CvsException(final String message, final Throwable cause, final String cvsRoot) {
    super(message, cause);
    myCvsRoot = cvsRoot;
  }

  public CvsException(Collection<String> messages, String cvsRoot) {
    super(messages);
    myCvsRoot = cvsRoot;
  }

  public String getCvsRoot() {
    return myCvsRoot;
  }
}
