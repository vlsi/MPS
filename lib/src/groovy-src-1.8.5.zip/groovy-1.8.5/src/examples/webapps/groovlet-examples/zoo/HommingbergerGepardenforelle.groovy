package zoo

class HommingbergerGepardenforelle extends zoo.fish.Trout {

  String saySomething(String something) {
    return something;
  }
  
}