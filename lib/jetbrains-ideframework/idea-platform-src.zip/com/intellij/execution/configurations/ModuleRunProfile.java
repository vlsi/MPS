package com.intellij.execution.configurations;

/**
 * @author spleaner
 */
public interface ModuleRunProfile extends RunProfileWithCompileBeforeLaunchOption {
}