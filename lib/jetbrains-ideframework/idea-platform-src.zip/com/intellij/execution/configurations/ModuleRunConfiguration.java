package com.intellij.execution.configurations;

/**
 * @author spleaner
 */
public interface ModuleRunConfiguration extends RunConfiguration, ModuleRunProfile {
}
