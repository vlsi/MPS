package com.intellij.execution.ui;

/**
 * @author Gregory.Shrago
 */
public interface ExecutionConsoleEx extends ExecutionConsole {
  void buildUi(final RunnerLayoutUi layoutUi);
}
