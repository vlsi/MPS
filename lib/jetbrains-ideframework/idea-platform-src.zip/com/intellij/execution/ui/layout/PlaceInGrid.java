package com.intellij.execution.ui.layout;

public enum PlaceInGrid {
  left, center, right, bottom
}