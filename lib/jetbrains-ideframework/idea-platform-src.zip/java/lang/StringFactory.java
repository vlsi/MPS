package java.lang;

/**
 * @author ik
 */
public class StringFactory {
  public static String createStringFromConstantArray(char[] buffer, int offset, int length) {
    assert length >= 0;
    assert offset >= 0;
    assert offset + length <= buffer.length;
    return new String(offset, length, buffer);
  }

  public static String createStringFromConstantArray(char[] buffer){
    return new String(0, buffer.length, buffer);
  }
}
