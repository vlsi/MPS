package com.intellij.codeInspection;

import com.intellij.xml.XmlBundle;

/**
 * @author Dmitry Avdeev
 */
public interface JspInspectionGroupNames {
  String JSP_INSPECTIONS = XmlBundle.message("jsp.inspections.group.name");
}
