/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jam.view.treetable;

import com.intellij.ide.util.treeView.AbstractTreeBuilder;
import com.intellij.ide.util.treeView.NodeDescriptor;
import com.intellij.ide.util.treeView.TreeState;
import com.intellij.jam.view.tree.JamAbstractTreeBuilder;
import com.intellij.jam.view.tree.JamNodeDescriptor;
import com.intellij.jam.view.tree.JamTreeStructure;
import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Disposer;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.ui.PopupHandler;
import com.intellij.ui.ScrollPaneFactory;
import com.intellij.ui.treeStructure.SimpleTree;
import com.intellij.util.ArrayUtil;
import com.intellij.util.EditSourceOnDoubleClickHandler;
import com.intellij.util.Icons;
import com.intellij.util.ui.UIUtil;
import com.intellij.util.ui.tree.TreeUtil;
import com.intellij.util.ui.update.Activatable;
import com.intellij.util.ui.update.UiNotifyConnector;
import com.intellij.util.xml.ui.CommittablePanel;
import com.intellij.util.xml.ui.EmptyPane;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;

/**
 * @author peter
 */
public abstract class JamTreeView implements CommittablePanel, TypeSafeDataProvider {

  @NonNls private static final String TREE = "tree";
  @NonNls private static final String EMPTY = "empty";
  private final CardLayout myCardLayout;
  private final JPanel myContentPanel = new JPanel();
  private final EmptyPane myEmptyPane = new EmptyPane("If you see this text, please, submit a bug");
  private JComponent myComponent;
  private final SimpleTree myTree;

  private final AbstractTreeBuilder myBuilder;
  private final Project myProject;
  private boolean myTreeShowing = false;
  private TreeState mySavedState;

  public JamTreeView(final Project project, final JamNodeDescriptor rootDescriptor) {
    myProject = project;

    final DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode();
    myTree = new MyTree();

    myBuilder = new AbstractTreeBuilder(myTree, new DefaultTreeModel(rootNode), new JamTreeStructure(rootDescriptor, project) {
      @Override
      public Object[] getChildElements(final Object element) {
        return mySavedState == null ? super.getChildElements(element) : ArrayUtil.EMPTY_OBJECT_ARRAY;
      }
    }, JamAbstractTreeBuilder.NODE_DESCRIPTOR_COMPARATOR, false) {

      public boolean isAutoExpandNode(NodeDescriptor nodeDescriptor) {
        return false;
      }

      protected boolean isAlwaysShowPlus(final NodeDescriptor descriptor) {
        return false;
      }

      @Override
      protected boolean isSmartExpand() {
        return true;
      }

      protected Object getTreeStructureElement(NodeDescriptor nodeDescriptor) {
        return nodeDescriptor;
      }
    };

    Disposer.register(this, myBuilder);

    myTree.setDragEnabled(false);
    myTree.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    myTree.setRowHeight(Icons.CLASS_ICON.getIconHeight());

    myTree.setShowsRootHandles(true);
    UIUtil.setLineStyleAngled(myTree);
    myTree.setCellRenderer(new JamToolTipRenderer());
    myTree.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    final UiNotifyConnector uiNotify = new UiNotifyConnector(myTree, new Activatable() {
      public void showNotify() {
        if (mySavedState != null) {
          refreshView();
        }
      }

      public void hideNotify() {
        mySavedState = TreeState.createOn(myTree);
      }
    });
    Disposer.register(myBuilder, uiNotify);

    myTree.addComponentListener(new ComponentAdapter() {
      @Override
      public void componentShown(final ComponentEvent e) {
        if (mySavedState != null) {
          refreshView();
        }
      }

    });

    EditSourceOnDoubleClickHandler.install(myTree);

    myCardLayout = new CardLayout();
    myContentPanel.setLayout(myCardLayout);
    myContentPanel.add(myEmptyPane.getComponent(), EMPTY);
    myContentPanel.add(ScrollPaneFactory.createScrollPane(myTree), TREE);
  }

  protected final void init() {
    myComponent = createMainComponent(myContentPanel, createToolbar());
    final ActionGroup actionGroup = createActionGroup(true);
    if (actionGroup != null) {
      PopupHandler.installPopupHandler(myEmptyPane.getComponent(), actionGroup, ActionPlaces.J2EE_ATTRIBUTES_VIEW_POPUP, ActionManager.getInstance());
      PopupHandler.installPopupHandler(myTree, actionGroup, ActionPlaces.J2EE_ATTRIBUTES_VIEW_POPUP, ActionManager.getInstance());
    }
    reset();
  }

  protected JComponent createMainComponent(final JComponent content, final JComponent toolbar) {
    final JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    panel.add(content, BorderLayout.CENTER);

    if (toolbar != null) {
      panel.add(toolbar, BorderLayout.NORTH);
    }
    return panel;
  }

  public final SimpleTree getTree() {
    return myTree;
  }

  public final Project getProject() {
    return myProject;
  }

  @NotNull
  public AbstractTreeBuilder getTreeBuilder() {
    return myBuilder;
  }

  public final void refreshView() {
    boolean showTree = isShowTree();
    final boolean visibilityChanged = showTree != myTreeShowing;
    if (visibilityChanged || showTree) {
      final TreeState stateToRestore = mySavedState == null? null/*TreeState.createOn(myTree)*/ : mySavedState;
      if (myTree.isShowing()) mySavedState = null;
      final TreePath[] selection = myTree.getSelectionPaths();
      final int[] selectionRows = selection == null? null : new int[selection.length];
      if (selection != null) {
        for (int i = 0; i < selectionRows.length; i++) {
          selectionRows[i] = myTree.getRowForPath(selection[i]);
        }
      }
      myBuilder.updateFromRoot();
      if (stateToRestore != null) stateToRestore.applyTo(myTree);
      if (!myTree.isExpanded(0)) {
        TreeUtil.expandRootChildIfOnlyOne(myTree);
      }
      myTree.getSelectionModel().clearSelection();
      if (selection != null) {
        for (int i = 0; i < selection.length; i++) {
          final TreePath path = selection[i];
          final int row = myTree.getRowForPath(path);
          if (row > -1) {
            myTree.addSelectionPath(path);
          }
          else {
            myTree.addSelectionRow(Math.min(selectionRows[i], myTree.getRowCount()-1));
          }
        }
      }
    }
    if (!showTree) {
      //noinspection HardCodedStringLiteral
      myEmptyPane.setText("<html>" + getEmptyPaneText() + "</html>");
    }
    if (visibilityChanged) {
      myTreeShowing = showTree;
      if (showTree) {
        TreeUtil.expandRootChildIfOnlyOne(myTree);
        myCardLayout.show(myContentPanel, TREE);
      }
      else {
        myCardLayout.show(myContentPanel, EMPTY);
      }
      myContentPanel.requestFocus();
    }
  }

  @Nullable
  protected ActionGroup createActionGroup(final boolean isPopup) {
    return isPopup? createPopupActionGroup() : createToolbarActions();
  }

  @Nullable
  protected ActionGroup createPopupActionGroup() {
    return null;
  }

  @Nullable
  protected ActionGroup createToolbarActions() {
    return null;
  }

  @Nullable
  protected JComponent createToolbar() {
    final ActionGroup actionGroup = createActionGroup(false);
    if (actionGroup == null) return null;

    final JComponent component = ActionManager.getInstance().createActionToolbar(ActionPlaces.PROJECT_VIEW_TOOLBAR, actionGroup, true).getComponent();
    component.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.darkGray), component.getBorder()));
    return component;
  }

  public void dispose() {
  }

  public JComponent getComponent() {
    return myComponent;
  }

  public void reset() {
    refreshView();
  }

  public void commit() {
  }

  private static JamNodeDescriptor getJamNodeDescriptor(final Object nodeDescriptor) throws LoadingNodeException{
    final DefaultMutableTreeNode node = (DefaultMutableTreeNode)nodeDescriptor;
    if (AbstractTreeBuilder.isLoadingNode(node)) {
      throw new LoadingNodeException();
    }

    return (JamNodeDescriptor)node.getUserObject();
  }

  private static class LoadingNodeException extends Exception {

  }

  protected abstract boolean isShowTree();

  @NotNull
  protected String getEmptyPaneText() {
    return "";
  }

  @Nullable
  public Object getSelectedElement() {
    NodeDescriptor descriptor = getSelectedDescriptor();
    return descriptor == null ? null : descriptor.getElement();
  }

  @Nullable
  public final JamNodeDescriptor getSelectedDescriptor() {
    final TreePath path = getSelectedPath();
    if (path != null) {
      Object lastPathComponent = path.getLastPathComponent();
      if (lastPathComponent instanceof DefaultMutableTreeNode) {
        try {
          return getJamNodeDescriptor(lastPathComponent);
        }
        catch (LoadingNodeException e) {
        }
      }
    }
    return null;
  }

  @NotNull
  public Object[] getSelectedElements() {
    final JamNodeDescriptor[] descriptors = getSelectedDescriptors();
    final Object[] result = new Object[descriptors.length];
    for (int i = 0; i < result.length; i++) {
      result[i] = descriptors[i].getElement();
    }
    return result;
  }

  @NotNull
  public final JamNodeDescriptor[] getSelectedDescriptors() {
    final TreePath[] treePaths = myTree.getSelectionPaths();
    if (treePaths == null) return JamNodeDescriptor.EMPTY_ARRAY;
    final ArrayList<JamNodeDescriptor> result = new ArrayList<JamNodeDescriptor>();
    for (TreePath path : treePaths) {
      final Object lastPathComponent = path.getLastPathComponent();
      if (lastPathComponent instanceof DefaultMutableTreeNode) {
        try {
          result.add(getJamNodeDescriptor(lastPathComponent));
        }
        catch (LoadingNodeException e) {
        }
      }
    }
    return result.toArray(new JamNodeDescriptor[result.size()]);
  }

  @Nullable
  private TreePath getSelectedPath() {
    final TreePath[] paths = myTree == null ? null : myTree.getSelectionPaths();
    return paths != null && paths.length == 1 ? paths[0] : null;
  }

  public void calcData(final DataKey key, final DataSink sink) {
    if (DataKeys.PSI_ELEMENT.equals(key)) {
      Object element = getSelectedElement();
      sink.put(DataKeys.PSI_ELEMENT, element instanceof PsiElement && ((PsiElement)element).isValid() ? (PsiElement)element : null);
    }
    else if (DataKeys.PSI_FILE.equals(key)) {
      Object element = getSelectedElement();
      sink.put(DataKeys.PSI_FILE, element instanceof PsiFile ? (PsiFile)element : null);
    }
    else if (DataKeys.PROJECT.equals(key)) {
      sink.put(DataKeys.PROJECT, myProject);
    }
    NodeDescriptor descriptor = getSelectedDescriptor();
    if (descriptor instanceof JamNodeDescriptor) {
      sink.put(key, ((JamNodeDescriptor)descriptor).getDataForElement(key.getName()));
    }
  }

  private class MyTree extends SimpleTree implements TypeSafeDataProvider {
    public void calcData(final DataKey key, final DataSink sink) {
      JamTreeView.this.calcData(key, sink);
    }
  }

}