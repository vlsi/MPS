/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jam.view.treetable;

import com.intellij.ide.TreeExpander;
import com.intellij.util.ui.tree.TreeUtil;

/**
 * @author Gregory.Shrago
 */
public class JamTreeTableViewExpander implements TreeExpander {
  private final JamTreeTableView myView;

  public JamTreeTableViewExpander(final JamTreeTableView view) {
    myView = view;
  }

  public void expandAll() {
    TreeUtil.expandAll(myView.getTree());
    final int selectedRow = myView.getTreeTableView().getSelectedRow();
    if (selectedRow != -1) {
      myView.getTreeTableView().scrollRectToVisible(myView.getTreeTableView().getCellRect(selectedRow, 0, true));
    }
  }

  public boolean canExpand() {
    return myView.getTreeTableView().isShowing();
  }

  public void collapseAll() {
    TreeUtil.collapseAll(myView.getTree(), 1);
    final int selectedRow = myView.getTreeTableView().getSelectedRow();
    if (selectedRow != -1) {
      myView.getTreeTableView().scrollRectToVisible(myView.getTreeTableView().getCellRect(selectedRow, 0, true));
    }
  }

  public boolean canCollapse() {
    return myView.getTreeTableView().isShowing();

  }
}
