/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jam.view.treetable;

import com.intellij.ide.TreeExpander;
import com.intellij.util.ui.tree.TreeUtil;

/**
 * @author Gregory.Shrago
 */
public class JamTreeViewExpander implements TreeExpander {
  private final JamTreeView myView;

  public JamTreeViewExpander(final JamTreeView view) {
    myView = view;
  }

  public void expandAll() {
    TreeUtil.expandAll(myView.getTree());
    final int[] rowz = myView.getTree().getSelectionRows();
    if (rowz != null && rowz.length > 0) {
      TreeUtil.showRowCentered(myView.getTree(), rowz[0], false);
    }
  }

  public boolean canExpand() {
    return myView.getTree().isShowing();
  }

  public void collapseAll() {
    TreeUtil.collapseAll(myView.getTree(), 1);
    final int[] rowz = myView.getTree().getSelectionRows();
    if (rowz != null && rowz.length > 0) {
      TreeUtil.showRowCentered(myView.getTree(), rowz[0], false);
    }
  }

  public boolean canCollapse() {
    return myView.getTree().isShowing();

  }
}