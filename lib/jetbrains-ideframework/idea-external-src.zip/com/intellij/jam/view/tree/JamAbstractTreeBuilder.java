/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jam.view.tree;

import com.intellij.ide.util.treeView.NodeDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiDirectory;
import com.intellij.psi.PsiFile;
import com.intellij.ui.treeStructure.LazySimpleTreeBuilder;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.util.Comparator;

/**
 * @author peter
 */
public class JamAbstractTreeBuilder extends LazySimpleTreeBuilder {
  public static final Comparator<NodeDescriptor> NODE_DESCRIPTOR_COMPARATOR = new Comparator<NodeDescriptor>(){
    public int compare(final NodeDescriptor nodeDescriptor1, final NodeDescriptor nodeDescriptor2) {
      final JamNodeDescriptor JamNodeDescriptor1 = (JamNodeDescriptor)nodeDescriptor1;
      final JamNodeDescriptor JamNodeDescriptor2 = (JamNodeDescriptor)nodeDescriptor2;
      int weight1 = JamNodeDescriptor1.getWeight();
      int weight2 = JamNodeDescriptor2.getWeight();
      if (weight1 != weight2) {
        return weight1 - weight2;
      }
      String s1 = JamNodeDescriptor1.getName();
      String s2 = JamNodeDescriptor2.getName();
      if (s1 == null) return s2 == null ? 0 : -1;
      if (s2 == null) return +1;
      return s1.compareToIgnoreCase(s2);
    }

  };

  public JamAbstractTreeBuilder(final Project project, final JTree tree, DefaultTreeModel treeModel, JamNodeDescriptor rootDescriptor) {
    super(tree, treeModel, new JamTreeStructure(rootDescriptor, project), null);
    setNodeDescriptorComparator(NODE_DESCRIPTOR_COMPARATOR);
  }

  public boolean isAlwaysShowPlus(NodeDescriptor nodeDescriptor) {
    return false;
  }

  public boolean isAutoExpandNode(NodeDescriptor nodeDescriptor) {
    return true;
  }

  protected final void expandNodeChildren(final DefaultMutableTreeNode node) {
    Object element = ((JamNodeDescriptor)node.getUserObject()).getElement();
    VirtualFile virtualFile = null;
    if (element instanceof PsiDirectory){
      virtualFile = ((PsiDirectory)element).getVirtualFile();
    }
    else if (element instanceof PsiFile){
      virtualFile = ((PsiFile)element).getVirtualFile();
    }
    if (virtualFile != null) {
      virtualFile.refresh(true, false);
    }
    super.expandNodeChildren(node);
  }

  public void init() {
    initRootNode();
  }

  public void runAfterUpdate(final Runnable runnable) {
    getUpdater().runAfterUpdate(runnable);
  }

  protected Object getTreeStructureElement(NodeDescriptor nodeDescriptor) {
    return nodeDescriptor;
  }

}