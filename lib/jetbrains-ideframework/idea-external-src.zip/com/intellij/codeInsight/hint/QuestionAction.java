package com.intellij.codeInsight.hint;

public interface QuestionAction{
  boolean execute();
}