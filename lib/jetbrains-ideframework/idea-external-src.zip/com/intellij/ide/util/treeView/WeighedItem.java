package com.intellij.ide.util.treeView;

/**
 * @author yole
 */
public interface WeighedItem {
  int getWeight();
}