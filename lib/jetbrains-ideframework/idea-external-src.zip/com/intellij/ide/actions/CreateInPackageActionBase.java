/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.ide.actions;

import com.intellij.ide.IdeView;
import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.psi.*;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * @author mike
 */
public abstract class CreateInPackageActionBase extends CreateElementActionBase {
  protected CreateInPackageActionBase(String text, String description, Icon icon) {
    super(text, description, icon);
  }

  public void update(AnActionEvent e) {
    super.update(e);
    DataContext dataContext = e.getDataContext();
    Project project = PlatformDataKeys.PROJECT.getData(dataContext);
    Presentation presentation = e.getPresentation();
    if (presentation.isEnabled()) {
      IdeView view = LangDataKeys.IDE_VIEW.getData(dataContext);
      assert view != null;
      ProjectFileIndex projectFileIndex = ProjectRootManager.getInstance(project).getFileIndex();
      PsiDirectory[] dirs = view.getDirectories();
      for (PsiDirectory dir : dirs) {
        if (projectFileIndex.isInSourceContent(dir.getVirtualFile()) && isGoodDir(dir)) {
          return;
        }
      }

      presentation.setEnabled(false);
      presentation.setVisible(false);
    }
  }

  protected boolean isGoodDir(final PsiDirectory dir) {
    return JavaDirectoryService.getInstance().getPackage(dir) != null;
    }

  protected final void checkBeforeCreate(String newName, PsiDirectory directory) throws IncorrectOperationException {
     PsiDirectory dir = directory;
     String className = newName;

     if (newName.contains(".")) {
       dir = getTopLevelDir(dir);

       String[] names = newName.split("\\.");

       for (int i = 0; i < names.length - 1; i++) {
         String name = names[i];
         PsiDirectory subDir = dir.findSubdirectory(name);

         if (subDir == null) {
           dir.checkCreateSubdirectory(name);
           return;
         }

         dir = subDir;
       }

       className = names[names.length - 1];
     }

     doCheckCreate(dir, className);
   }

   @NotNull
   protected final PsiElement[] create(String newName, PsiDirectory directory) throws IncorrectOperationException {
     PsiDirectory dir = directory;
     String className = newName;

     if (newName.contains(".")) {
       dir = getTopLevelDir(dir);

       String[] names = newName.split("\\.");

       for (int i = 0; i < names.length - 1; i++) {
         String name = names[i];
         PsiDirectory subDir = dir.findSubdirectory(name);

         if (subDir == null) {
           subDir = dir.createSubdirectory(name);
         }

         dir = subDir;
       }

       className = names[names.length - 1];
     }

     final PsiClass psiClass = doCreate(dir, className);
     return new PsiElement[]{psiClass, psiClass.getLBrace()};  // ensure convenient caret position (IDEADEV-20383) 
   }

  @NotNull
  private static PsiDirectory getTopLevelDir(PsiDirectory dir) throws IncorrectOperationException {
    JavaDirectoryService directoryService = JavaDirectoryService.getInstance();
    while (true) {
      PsiDirectory parent = dir.getParentDirectory();
      if (parent == null) throw new IncorrectOperationException("No parent directory found for "+dir.getVirtualFile().getPresentableUrl());
      PsiPackage parentPackage = directoryService.getPackage(parent);
      if (parentPackage == null) break;
      dir = parent;
    }

    return dir;
  }

  protected abstract void doCheckCreate(final PsiDirectory dir, final String className) throws IncorrectOperationException;
  protected abstract PsiClass doCreate(final PsiDirectory dir, final String className) throws IncorrectOperationException;
}
