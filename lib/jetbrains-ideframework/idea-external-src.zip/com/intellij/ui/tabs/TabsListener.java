package com.intellij.ui.tabs;

public interface TabsListener {

  void selectionChanged(TabInfo oldSelection, TabInfo newSelection);

}
