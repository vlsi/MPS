package com.intellij.ui.tabs.impl;

public class TabLayout {
}
