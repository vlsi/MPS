/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.psi.jsp.el;

import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.TokenSet;
import com.intellij.psi.tree.jsp.el.IELElementType;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: Feb 11, 2005
 * Time: 7:00:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ELTokenType {
  IElementType JSP_EL_START = new IELElementType("EL_START");
  IElementType JSF_EL_START = new IELElementType("JSF_EL_START");
  IElementType JSP_EL_END = new IELElementType("EL_END");
  IElementType JSP_EL_CONTENT = new IELElementType("EL_CONTENT");
  IElementType JSP_EL_AND = new IELElementType("EL_AND");
  IElementType JSP_EL_OR = new IELElementType("EL_OR");
  IElementType JSP_EL_NOT = new IELElementType("EL_NOT");
  IElementType JSP_EL_NOT_KEYWORD = new IELElementType("EL_NOT_KEYWORD");
  IElementType JSP_EL_WHITESPACE = new IELElementType("JSP_EL_WHITESPACE");
  IElementType JSP_EL_LT = new IELElementType("EL_LT");
  IElementType JSP_EL_GT = new IELElementType("EL_GT");
  IElementType JSP_EL_EQ = new IELElementType("EL_EQ");
  IElementType JSP_EL_NE = new IELElementType("EL_NE");
  IElementType JSP_EL_GE = new IELElementType("EL_GE");
  IElementType JSP_EL_LE = new IELElementType("EL_LE");
  IElementType JSP_EL_NULL = new IELElementType("EL_NULL");
  IElementType JSP_EL_TRUE = new IELElementType("EL_TRUE");
  IElementType JSP_EL_FALSE = new IELElementType("EL_FALSE");
  IElementType JSP_EL_INSTANCEOF = new IELElementType("EL_INSTANCEOF");
  IElementType JSP_EL_EMPTY = new IELElementType("EL_EMPTY");
  IElementType JSP_EL_DIV = new IELElementType("EL_DIV");
  IElementType JSP_EL_MOD = new IELElementType("EL_MOD");
  IElementType JSP_EL_IDENTIFIER = new IELElementType("EL_IDENTIFIER");
  IElementType JSP_EL_GREATER = new IELElementType("EL_GREATER");
  IElementType JSP_EL_LESS = new IELElementType("EL_LESS");
  IElementType JSP_EL_GREATER_OR_EQUAL = new IELElementType("EL_GREATER_OR_EQUAL");
  IElementType JSP_EL_LESS_OR_EQUAL = new IELElementType("EL_LESS_OR_EQUAL");

  IElementType JSP_EL_STRING_LITERAL = new IELElementType("EL_STRING_LITERAL");
  IElementType JSP_EL_ESCAPED_STRING_LITERAL = new IELElementType("EL_ESCAPED_STRING_LITERAL");

  IElementType JSP_EL_LBRACKET = new IELElementType("EL_LBRACKET");
  IElementType JSP_EL_RBRACKET = new IELElementType("EL_RBRACKET");
  IElementType JSP_EL_LPARENTH = new IELElementType("EL_LPARENTH");
  IElementType JSP_EL_RPARENTH = new IELElementType("EL_RPARENTH");
  IElementType JSP_EL_DOT = new IELElementType("EL_DOT");
  IElementType JSP_EL_MINUS = new IELElementType("EL_MINUS");
  IElementType JSP_EL_NEGATE = new IELElementType("EL_NEGATE");
  IElementType JSP_EL_DIVISION = new IELElementType("EL_DIVISION");
  IElementType JSP_EL_MODULO = new IELElementType("EL_MODULO");
  IElementType JSP_EL_MULTIPLY = new IELElementType("EL_MULTIPLY");
  IElementType JSP_EL_PLUS = new IELElementType("EL_PLUS");
  IElementType JSP_EL_NOT_EQUAL = new IELElementType("EL_NOT_EQUAL");
  IElementType JSP_EL_EQUAL = new IELElementType("EL_EQUAL");
  IElementType JSP_EL_AND_AND = new IELElementType("EL_AND_AND");
  IElementType JSP_EL_OR_OR = new IELElementType("EL_OR_OR");
  IElementType JSP_EL_QUEST = new IELElementType("EL_QUEST");
  IElementType JSP_EL_SEMICOLON = new IELElementType("EL_SEMICOLON");
  IElementType JSP_EL_COMMA = new IELElementType("EL_COMMA");
  IElementType JSP_EL_INTEGER_LITERAL = new IELElementType("EL_INT_LITERAL");
  IElementType JSP_EL_FLOATING_POINT_LITERAL = new IELElementType("EL_FP_LITERAL");
  TokenSet JSP_EL_UNARY_OPERATIONS = TokenSet.create(
    JSP_EL_NOT, JSP_EL_NOT_KEYWORD, JSP_EL_MINUS, JSP_EL_EMPTY
  );
  TokenSet JSP_EL_KEYWORDS = TokenSet.create(
      JSP_EL_AND, JSP_EL_OR, JSP_EL_NOT_KEYWORD, JSP_EL_EQ, JSP_EL_NE, JSP_EL_GT, JSP_EL_LT, JSP_EL_GE, JSP_EL_LE,
      JSP_EL_TRUE, JSP_EL_FALSE, JSP_EL_NULL, JSP_EL_INSTANCEOF, JSP_EL_EMPTY, JSP_EL_DIV, JSP_EL_MOD
  );
  TokenSet JSP_EL_BINARY_OPERATIONS = TokenSet.create(
      JSP_EL_AND, JSP_EL_OR, JSP_EL_EQ, JSP_EL_NE, JSP_EL_GT, JSP_EL_LT, JSP_EL_GE, JSP_EL_LE,
      JSP_EL_INSTANCEOF, JSP_EL_EMPTY, JSP_EL_DIV, JSP_EL_MOD, JSP_EL_LESS, JSP_EL_GREATER, JSP_EL_GREATER_OR_EQUAL,
      JSP_EL_LESS_OR_EQUAL, JSP_EL_EQUAL, JSP_EL_NOT_EQUAL, JSP_EL_DIVISION, JSP_EL_MODULO, JSP_EL_MULTIPLY, JSP_EL_PLUS,
      JSP_EL_AND_AND, JSP_EL_OR_OR
  );
}
