/*
* Copyright (c) 2008 Your Corporation. All Rights Reserved.
*/
package com.intellij.codeInsight.completion;

/**
 * @author peter
 */
public enum CompletionType {
  BASIC, SMART, CLASS_NAME
}
