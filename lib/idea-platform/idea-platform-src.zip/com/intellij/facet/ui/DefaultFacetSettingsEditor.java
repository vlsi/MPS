package com.intellij.facet.ui;

import com.intellij.openapi.options.UnnamedConfigurable;

/**
 * @author nik
 */
public abstract class DefaultFacetSettingsEditor implements UnnamedConfigurable {
}
