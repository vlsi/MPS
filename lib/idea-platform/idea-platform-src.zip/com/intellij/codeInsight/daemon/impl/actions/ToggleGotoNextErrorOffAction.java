package com.intellij.codeInsight.daemon.impl.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;

/**
 * @author cdr
 */
public class ToggleGotoNextErrorOffAction extends ToggleGotoNextErrorOnAction {
    public ToggleGotoNextErrorOffAction(String text) {
      super(text);
    }

    public boolean isSelected(AnActionEvent event) {
      return !super.isSelected(event);
    }

    public void setSelected(AnActionEvent event,boolean flag) {
      super.setSelected(event, !flag);
    }
  }
