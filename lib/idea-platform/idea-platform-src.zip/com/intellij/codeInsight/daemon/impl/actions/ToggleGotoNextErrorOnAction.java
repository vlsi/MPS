package com.intellij.codeInsight.daemon.impl.actions;

import com.intellij.codeInsight.daemon.DaemonCodeAnalyzerSettings;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.ToggleAction;

/**
 * @author cdr
 */
public class ToggleGotoNextErrorOnAction extends ToggleAction {
    public ToggleGotoNextErrorOnAction(String text) {
      super(text);
    }

    public boolean isSelected(AnActionEvent event) {
      DaemonCodeAnalyzerSettings settings = DaemonCodeAnalyzerSettings.getInstance();
      return settings.NEXT_ERROR_ACTION_GOES_TO_ERRORS_FIRST;
    }

    public void setSelected(AnActionEvent event,boolean flag) {
      DaemonCodeAnalyzerSettings settings = DaemonCodeAnalyzerSettings.getInstance();
      settings.NEXT_ERROR_ACTION_GOES_TO_ERRORS_FIRST = flag;
    }
  }
