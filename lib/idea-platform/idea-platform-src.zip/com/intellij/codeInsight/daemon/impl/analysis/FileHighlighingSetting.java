package com.intellij.codeInsight.daemon.impl.analysis;

public enum FileHighlighingSetting {
  NONE,
  SKIP_HIGHLIGHTING,
  FORCE_HIGHLIGHTING,
  SKIP_INSPECTION
}
