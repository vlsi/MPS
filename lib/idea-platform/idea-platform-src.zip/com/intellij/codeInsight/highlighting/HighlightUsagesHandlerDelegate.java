package com.intellij.codeInsight.highlighting;

import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.psi.PsiFile;

/**
 * @author yole
 */
public interface HighlightUsagesHandlerDelegate {
  ExtensionPointName<HighlightUsagesHandlerDelegate> EP_NAME = ExtensionPointName.create("com.intellij.highlightUsagesHandler");
  
  boolean highlightUsages(Editor editor, PsiFile file);
}
