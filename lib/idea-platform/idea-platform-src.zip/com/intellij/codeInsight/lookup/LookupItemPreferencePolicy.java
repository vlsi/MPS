
package com.intellij.codeInsight.lookup;

import java.util.Comparator;

public interface LookupItemPreferencePolicy extends Comparator<LookupItem> {
  void setPrefix(String prefix);
  void itemSelected(LookupItem item);
}