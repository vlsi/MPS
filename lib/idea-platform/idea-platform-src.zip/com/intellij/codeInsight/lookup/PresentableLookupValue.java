package com.intellij.codeInsight.lookup;

/**
 * Created by IntelliJ IDEA.
 * User: maxim
 * Date: 10.12.2004
 * Time: 13:38:25
 * To change this template use File | Settings | File Templates.
 */
public interface PresentableLookupValue {
   String getPresentation();
}
