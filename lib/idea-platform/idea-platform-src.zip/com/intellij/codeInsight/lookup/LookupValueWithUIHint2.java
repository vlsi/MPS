package com.intellij.codeInsight.lookup;

/**
 * @by maxim
 */
public interface LookupValueWithUIHint2 extends LookupValueWithUIHint {
  boolean isStrikeout();
}