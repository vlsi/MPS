/*
 * Created by IntelliJ IDEA.
 * User: mike
 * Date: Jun 6, 2002
 * Time: 2:37:38 PM
 * To change template for new class use 
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package com.intellij.codeInsight.lookup.impl;

import com.intellij.openapi.actionSystem.IdeActions;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.editor.actionSystem.EditorActionManager;
import org.jetbrains.annotations.NotNull;

public class LookupManagerActions implements ApplicationComponent {
  public LookupManagerActions(EditorActionManager actionManager) {
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_UP, new UpHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_UP)));
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_DOWN, new DownHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_DOWN)));
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_PAGE_UP, new PageUpHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_PAGE_UP)));
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_PAGE_DOWN, new PageDownHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_MOVE_CARET_PAGE_DOWN)));
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_MOVE_LINE_START, new HomeHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_MOVE_LINE_START)));
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_MOVE_LINE_END, new EndHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_MOVE_LINE_END)));
    actionManager.setActionHandler(IdeActions.ACTION_EDITOR_BACKSPACE, new BackspaceHandler(actionManager.getActionHandler(IdeActions.ACTION_EDITOR_BACKSPACE)));
    actionManager.getTypedAction().setupHandler(new TypedHandler(actionManager.getTypedAction().getHandler()));
  }

  public void initComponent() { }

  public void disposeComponent() {
  }

  @NotNull
  public String getComponentName() {
    return "LookupManagerActions";
  }
}
