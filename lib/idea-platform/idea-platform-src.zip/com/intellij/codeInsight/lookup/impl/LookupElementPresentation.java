package com.intellij.codeInsight.lookup.impl;

import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.openapi.util.UserDataHolder;

import javax.swing.*;
import java.awt.*;

/**
 * @author yole
 */
public interface LookupElementPresentation extends UserDataHolder {
  void setItemText(String text);
  void setItemText(final String text, boolean strikeout);

  void setTailText(String text);
  void setTailText(String text, boolean strikeout);
  void setTailText(String text, Color foreground, boolean bold);

  void setTypeText(String text);
  void setTypeText(String text, Icon icon);

  LookupItem[] getItems();
  int getMaxLength();

  boolean trimText();
}
