package com.intellij.codeInsight.hint;

/**
 * @author yole
 */
public interface ScrollAwareHint {
  void editorScrolled();
}