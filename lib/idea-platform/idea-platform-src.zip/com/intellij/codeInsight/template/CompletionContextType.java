package com.intellij.codeInsight.template;

import com.intellij.psi.PsiFile;
import com.intellij.codeInsight.template.impl.TemplateContext;
import com.intellij.codeInsight.CodeInsightBundle;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;

/**
 * @author yole
 */
public class CompletionContextType implements TemplateContextType {
  public String getName() {
    return CodeInsightBundle.message("dialog.edit.template.checkbox.smart.type.completion");
  }

  public boolean isInContext(final PsiFile file, final int offset) {
    return false;
  }

  public boolean isEnabled(final TemplateContext context) {
    return context.COMPLETION;
  }

  public void setEnabled(final TemplateContext context, final boolean value) {
    context.COMPLETION = value;
  }

  public SyntaxHighlighter createHighlighter() {
    return null;
  }
}
