package com.intellij.codeInsight.completion;

import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.codeInsight.lookup.LookupItemPreferencePolicy;

public class LookupData{
  public final LookupItem[] items;
  public String prefix;
  //int indexToSelect = -1;
  public LookupItemPreferencePolicy itemPreferencePolicy;

  public LookupData(LookupItem[] items, String prefix) {
    this.items = items;
    this.prefix = prefix;
  }

  public static final LookupData EMPTY = new LookupData(LookupItem.EMPTY_ARRAY, null);
}
