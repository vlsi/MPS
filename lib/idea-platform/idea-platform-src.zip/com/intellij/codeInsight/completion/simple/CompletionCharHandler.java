/*
 * Copyright (c) 2000-2007 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.codeInsight.completion.simple;

import com.intellij.codeInsight.TailType;
import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.openapi.editor.Editor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author peter
 */
public interface CompletionCharHandler<T> {

  /**
   * @param editor
   * @param element
   * @param completionChar
   * @return null if default handler should be used
   */
  @Nullable
  TailType handleCompletionChar(@NotNull final Editor editor, @NotNull final LookupElement<T> element, final char completionChar);

}
