/*
 * Copyright (c) 2000-2007 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.codeInsight.completion.simple;

import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.ScrollType;
import com.intellij.openapi.editor.Document;
import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.codeInsight.lookup.Lookup;
import com.intellij.codeInsight.TailType;
import com.intellij.codeInsight.completion.InsertHandler;
import com.intellij.codeInsight.completion.CompletionContext;
import com.intellij.codeInsight.completion.LookupData;
import com.intellij.codeInsight.completion.CompletionUtil;
import com.intellij.util.IncorrectOperationException;
import com.intellij.psi.PsiDocumentManager;
import org.jetbrains.annotations.NotNull;

/**
 * @author peter
 */
public abstract class SimpleInsertHandler implements InsertHandler{
  public static final SimpleInsertHandler EMPTY_HANDLER = new SimpleInsertHandler() {
    public int handleInsert(final Editor editor, final int startOffset, final LookupElement item, final LookupElement[] allItems, final TailType tailType,
                            final char completionChar) {
      return editor.getCaretModel().getOffset();
    }
  };
  public static final CompletionCharHandler DEFAULT_COMPLETION_CHAR_HANDLER = new CompletionCharHandler() {
    public TailType handleCompletionChar(@NotNull final Editor editor, @NotNull final LookupElement lookupElement, final char completionChar) {
      if (completionChar == Lookup.REPLACE_SELECT_CHAR) {
        final int offset = editor.getCaretModel().getOffset();
        final Document document = editor.getDocument();
        final CharSequence sequence = document.getCharsSequence();
        int i = offset;
        while (i < sequence.length() && Character.isJavaIdentifierPart(sequence.charAt(i))) i++;
        document.deleteString(offset, i);
        PsiDocumentManager.getInstance(editor.getProject()).commitDocument(editor.getDocument());
      }
      final LookupItem<?> item = (LookupItem)lookupElement;
      switch(completionChar){
        case '.': return TailType.DOT;
        case ',': return TailType.COMMA;
        case ';': return TailType.SEMICOLON;
        case '=': return TailType.EQ;
        case ' ': return TailType.SPACE;
        case '!': return TailType.EXCLAMATION;
        case ':': return TailType.CASE_COLON; //?
      }
      final TailType attr = item.getAttribute(CompletionUtil.TAIL_TYPE_ATTR);
      return attr != null ? attr : TailType.NONE;
    }

  };

  public void handleInsert(final CompletionContext context, final int startOffset, final LookupData data, final LookupItem item,
                           final boolean signatureSelected,
                           final char completionChar) {
    final Editor editor = context.editor;
      TailType tailType = item.getCompletionCharHandler().handleCompletionChar(editor, item, completionChar);
      if (tailType == null) {
        tailType = DEFAULT_COMPLETION_CHAR_HANDLER.handleCompletionChar(editor, item, completionChar);
      }
      assert tailType != null;
      final int tailOffset;
      try {
        tailOffset = handleInsert(editor, startOffset, item, data.items, tailType, completionChar);
      }
      catch (IncorrectOperationException e) {
        throw new RuntimeException(e);
      }
      assert !PsiDocumentManager.getInstance(context.project).isDocumentBlockedByPsi(editor.getDocument()) : "InsertHandler has left document locked by PSI operations: " + this;
      tailType.processTail(editor, tailOffset);
      editor.getScrollingModel().scrollToCaret(ScrollType.RELATIVE);
      editor.getSelectionModel().removeSelection();
  }

  /**
   *
   * @param editor
   * @param startOffset
   * @param item
   * @param allItems
   * @param tailType @return tailOffset
   * @param completionChar
   */
  public abstract int handleInsert(Editor editor, int startOffset, LookupElement item, final LookupElement[] allItems, TailType tailType,
                                   final char completionChar)
    throws IncorrectOperationException;
}
