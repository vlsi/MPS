/*
 * Copyright (c) 2000-2005 by JetBrains s.r.o. All Rights Reserved.
 * Use is subject to license terms.
 */
package com.intellij.codeInsight.completion;

import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.openapi.util.Key;
import com.intellij.patterns.ElementPattern;
import com.intellij.psi.PsiElement;

/**
 * @author peter
 */
public interface CompletionRegistrar {
  Key<CompletionStatistician> STATISTICS_KEY = Key.create("completion");
  Key<CompletionWeigher> WEIGHER_KEY = Key.create("completion");
  Key<CompletionWeigher> PRESELECT_KEY = Key.create("preferredCompletionItem");

  void extend(CompletionType type, final ElementPattern<? extends PsiElement> place, CompletionProvider<LookupElement, CompletionParameters> provider);

  void extend(final ElementPattern<? extends PsiElement> place, CompletionAdvertiser advertiser);

}
