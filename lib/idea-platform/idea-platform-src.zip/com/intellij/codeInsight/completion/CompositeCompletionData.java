package com.intellij.codeInsight.completion;

import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiReference;
import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.Set;

public class CompositeCompletionData extends CompletionData{
  private final CompletionData[] myDataByPriority;

  public CompositeCompletionData(CompletionData... dataByPriority) {
    myDataByPriority = dataByPriority;
  }

  public void addKeywordVariants(final Set<CompletionVariant> set, final PsiElement position, final PsiFile file) {
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        Set<CompletionVariant> toAdd = new HashSet<CompletionVariant>();
        outer:
        for (final CompletionData completionData : myDataByPriority) {
          completionData.addKeywordVariants(toAdd, position, file);
          for (CompletionVariant completionVariant : toAdd) {
            if (completionVariant.hasKeywordCompletions()) {
              break outer;
            }
          }
        }
        set.addAll(toAdd);
      }
    });
  }

  public void completeReference(PsiReference reference, Set<LookupItem> set, @NotNull PsiElement position,
                                final PrefixMatcher matcher, final PsiFile file, final int offset) {
    myDataByPriority[0].completeReference(reference, set, position, matcher, file, offset);
  }

  public String findPrefix(PsiElement insertedElement, int offset) {
    for (final CompletionData completionData : myDataByPriority) {
      final String prefix = completionData.findPrefix(insertedElement, offset);
      if (prefix.length() > 0) return prefix;
    }
    return "";
  }
}
