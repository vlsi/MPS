package com.intellij.codeInsight.completion;

import com.intellij.codeInsight.CodeInsightSettings;

public class CodeCompletionHandler extends CodeCompletionHandlerBase {

  public CodeCompletionHandler() {
    super(CompletionType.BASIC);
  }

  protected boolean isAutocompleteOnInvocation() {
    return CodeInsightSettings.getInstance().AUTOCOMPLETE_ON_CODE_COMPLETION;
  }

  protected boolean isAutocompleteCommonPrefixOnInvocation() {
    return CodeInsightSettings.getInstance().AUTOCOMPLETE_COMMON_PREFIX;
  }

}
