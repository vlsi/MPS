package com.intellij.codeInsight.completion;

import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiPlainTextFile;
import com.intellij.psi.filters.TrueFilter;
import com.intellij.psi.filters.getters.AllWordsGetter;
import com.intellij.codeInsight.TailType;

public class WordCompletionData extends CompletionData {

  public String findPrefix (final PsiElement insertedElement, final int offset) {
    return findPrefixSimple(insertedElement, offset);
  }
  
  public static String findPrefixSimple(final PsiElement insertedElement, final int offset) {
    if(insertedElement == null) return "";
    final String text = insertedElement.getText();
    final int offsetInElement = offset - insertedElement.getTextRange().getStartOffset();
    int start = offsetInElement - 1;
    while(start >=0 ) {
      if(!Character.isJavaIdentifierPart(text.charAt(start))) break;
      --start;
    }

    return text.substring(start + 1, offsetInElement).trim();
  }

  public WordCompletionData() {
    final CompletionVariant variant = new CompletionVariant(PsiPlainTextFile.class, TrueFilter.INSTANCE);
    variant.includeScopeClass(PsiElement.class, false);

    variant.addCompletion(new AllWordsGetter(), TailType.SPACE);
    registerVariant(variant);
  }

}