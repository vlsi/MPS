package com.intellij.codeEditor.printing;

import org.jetbrains.annotations.NonNls;

/**
 * Created by IntelliJ IDEA.
 * User: Alexander.Chernikov
 * Date: 20.10.2006
 * Time: 18:55:05
 * To change this template use File | Settings | File Templates.
 */
public interface HelpID {
  @NonNls String EXPORT_TO_HTML = "reference.file.exportToHtml";
  @NonNls String PRINT = "reference.file.print";
}
