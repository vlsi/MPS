package com.intellij.application.options;

import com.intellij.ide.ui.search.SearchUtil;
import com.intellij.openapi.application.ApplicationBundle;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SearchableConfigurable;
import com.intellij.openapi.options.ex.GlassPanel;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.util.IconLoader;
import com.intellij.psi.codeStyle.CodeStyleScheme;
import com.intellij.psi.codeStyle.CodeStyleSchemes;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import com.intellij.psi.codeStyle.CodeStyleSettingsManager;
import com.intellij.psi.impl.source.codeStyle.CodeStyleSchemeImpl;
import com.intellij.ui.ScrollPaneFactory;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ProjectCodeStyleConfigurable implements SearchableConfigurable {
  private JPanel myMainPanel;
  private Project myProject;
  private JPanel myStackPanel;
  private CodeStyleSettingsPanel mySettingsPanel;
  private CardLayout myStackLayout;
  private JButton myExportButton;
  private JButton myImportButton;
  private JButton myEditGlobalButton;
  private JRadioButton myRbUsePerProject;
  private JRadioButton myRbUseGlobal;
  private boolean myWasImported = false;
  @NonNls
  private static final String CARD_NO = "NO";
  @NonNls
  private static final String CARD_YES = "YES";
  private GlassPanel myGlassPanel;

  public ProjectCodeStyleConfigurable(Project project) {
    myProject = project;
  }

  public static ProjectCodeStyleConfigurable getInstance(Project project) {
    return project.getComponent(ProjectCodeStyleConfigurable.class);
  }

  public String getDisplayName() {
    return ApplicationBundle.message("title.project.code.style");
  }

  public Icon getIcon() {
    return IconLoader.getIcon("/general/configurableCodeStyle.png");
  }

  public String getHelpTopic() {
    if (mySettingsPanel == null) return "reference.settingsdialog.project.codestyle";
    return mySettingsPanel.getHelpTopic();
  }

  public JComponent createComponent() {
    myMainPanel = new JPanel(new BorderLayout());
    ButtonGroup group = new ButtonGroup();

    myRbUsePerProject = new JRadioButton(ApplicationBundle.message("radio.use.per.project.code.style.scheme"));
    group.add(myRbUsePerProject);

    myRbUseGlobal = new JRadioButton(ApplicationBundle.message("radio.use.global.code.style"));
    group.add(myRbUseGlobal);

    myImportButton = new JButton(ApplicationBundle.message("button.import"));
    myExportButton = new JButton(ApplicationBundle.message("button.export"));
    myEditGlobalButton = new JButton(ApplicationBundle.message("button.edit.global.settings"));

    JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));

    JPanel headerGrid = new JPanel(new GridLayout(2, 2));
    headerGrid.add(myRbUseGlobal);

    JPanel globalButtonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
    globalButtonsPanel.add(myEditGlobalButton);
    headerGrid.add(globalButtonsPanel);

    JPanel projectButtonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
    projectButtonsPanel.add(myImportButton);
    projectButtonsPanel.add(myExportButton);
    headerGrid.add(myRbUsePerProject);
    headerGrid.add(projectButtonsPanel);

    header.add(headerGrid);

    myExportButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onExport();
      }
    });

    myImportButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onImport();
      }
    });

    myEditGlobalButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onEditGlobalSettings();
      }
    });

    myMainPanel.add(header, BorderLayout.NORTH);

    ActionListener listener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        updateByCheckbox();
      }
    };
    myRbUsePerProject.addActionListener(listener);
    myRbUseGlobal.addActionListener(listener);

    CodeStyleSettings initialSettings = CodeStyleSettingsManager.getInstance(myProject).PER_PROJECT_SETTINGS;
    if (initialSettings == null) {
      initialSettings = (CodeStyleSettings)CodeStyleSettingsManager.getInstance(myProject)
        .getCurrentSettings()
        .clone();
      initialSettings.setParentSettings(CodeStyleSchemes.getInstance().getDefaultScheme().getCodeStyleSettings());
    }
    mySettingsPanel = new CodeStyleSettingsPanel(initialSettings);
    mySettingsPanel.init();

    JPanel infoPanel = new JPanel(new BorderLayout());
    final JLabel label = new JLabel(ApplicationBundle.message("label.edit.per.project.or.global.code.style"));
    label.setIcon(IconLoader.getIcon("/general/tip.png"));
    label.setHorizontalAlignment(SwingConstants.CENTER);
    infoPanel.add(label, BorderLayout.CENTER);

    myStackLayout = new CardLayout();
    myStackPanel = new JPanel(myStackLayout);
    myStackPanel.add(CARD_NO, infoPanel);
    myStackPanel.add(CARD_YES, mySettingsPanel);

    myMainPanel.add(myStackPanel, BorderLayout.CENTER);

    if (CodeStyleSettingsManager.getInstance(myProject).USE_PER_PROJECT_SETTINGS) {
      myRbUsePerProject.setSelected(true);
    }
    else {
      myRbUseGlobal.setSelected(true);
    }

    myMainPanel.setPreferredSize(myMainPanel.getMinimumSize());
    myGlassPanel = new GlassPanel(myMainPanel);
    return myMainPanel;
  }

  private void onEditGlobalSettings() {
    CodeStyleSettingsManager.getInstance(myProject).USE_PER_PROJECT_SETTINGS = false;
    CodeStyleSettingsUtil.getInstance().showCodeStyleSettings(myProject, null);
  }

  private class ChooseSchemeDialog extends DialogWrapper {
    private CodeStyleScheme myChoosenScheme;
    private JList mySchemesList;

    public ChooseSchemeDialog() {
      super(myProject, false);
      setTitle(ApplicationBundle.message("title.choose.code.style.scheme"));
      init();
    }

    public CodeStyleScheme getChoosenScheme() {
      return myChoosenScheme;
    }

    protected JComponent createCenterPanel() {
      mySchemesList = new JList(CodeStyleSchemes.getInstance().getSchemes());
      mySchemesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      mySchemesList.setSelectedIndex(0);
      return ScrollPaneFactory.createScrollPane(mySchemesList);
    }

    protected void doOKAction() {
      myChoosenScheme = (CodeStyleScheme)mySchemesList.getSelectedValue();
      super.doOKAction();
    }
  }

  private void onImport() {
    ChooseSchemeDialog dlg = new ChooseSchemeDialog();
    dlg.show();
    final CodeStyleScheme choosenScheme = dlg.getChoosenScheme();
    if (choosenScheme != null) {
      CodeStyleSettings settings = (CodeStyleSettings)choosenScheme.getCodeStyleSettings().clone();
      settings.setParentSettings(CodeStyleSchemes.getInstance().getDefaultScheme().getCodeStyleSettings());
      myStackPanel.remove(mySettingsPanel);
      mySettingsPanel = new CodeStyleSettingsPanel(settings);
      mySettingsPanel.init();
      myStackPanel.add(CARD_YES, mySettingsPanel);
      myStackLayout.show(myStackPanel, CARD_YES);
      myWasImported = true;
    }
  }

  private void onExport() {
    final CodeStyleSchemes schemesManager = CodeStyleSchemes.getInstance();
    CodeStyleScheme[] schemes = schemesManager.getSchemes();
    ArrayList names = new ArrayList();
    for (int i = 0; i < schemes.length; i++) {
      names.add(schemes[i].getName());
    }
    SaveSchemeDialog saveDialog = new SaveSchemeDialog(myMainPanel, ApplicationBundle.message("title.save.code.style.scheme.as"), names);
    saveDialog.show();
    if (saveDialog.isOK()) {
      CodeStyleSchemeImpl newScheme =
        (CodeStyleSchemeImpl)schemesManager.createNewScheme(saveDialog.getSchemeName(), schemesManager.getDefaultScheme());
      newScheme.setCodeStyleSettings((CodeStyleSettings)mySettingsPanel.getSettings().clone());
      schemesManager.addScheme(newScheme);
    }
  }

  private void updateByCheckbox() {
    final boolean on = myRbUsePerProject.isSelected();
    myStackLayout.show(myStackPanel, on ? CARD_YES : CARD_NO);
    myImportButton.setEnabled(on);
    myExportButton.setEnabled(on);
    myEditGlobalButton.setEnabled(!on);
  }

  public void apply() throws ConfigurationException {
    mySettingsPanel.apply();
    CodeStyleSettingsManager.getInstance(myProject).USE_PER_PROJECT_SETTINGS = myRbUsePerProject.isSelected();
    CodeStyleSettingsManager.getInstance(myProject).PER_PROJECT_SETTINGS = mySettingsPanel.getSettings();
  }

  public void reset() {
    myMainPanel.getRootPane().setGlassPane(myGlassPanel);
    myRbUsePerProject.setSelected(CodeStyleSettingsManager.getInstance(myProject).USE_PER_PROJECT_SETTINGS);
    mySettingsPanel.reset();
    updateByCheckbox();
  }

  public boolean isModified() {
    return myWasImported || myRbUsePerProject.isSelected() != CodeStyleSettingsManager.getInstance(myProject).USE_PER_PROJECT_SETTINGS ||
           mySettingsPanel.isModified();
  }

  public void disposeUIResources() {
    if (mySettingsPanel != null) {
      mySettingsPanel.dispose();
      mySettingsPanel = null;
      myStackPanel = null;
    }
    myMainPanel = null;
  }

  public void selectPage(Class pageToSelect) {
    mySettingsPanel.selectTab(pageToSelect);
  }

  public String getId() {
    return "preferences.sourceCode";
  }

  public boolean clearSearch() {
    myGlassPanel.clear();
    return true;
  }

  @Nullable
  public Runnable enableSearch(String option) {
    if (!CodeStyleSettingsManager.getInstance(myProject).USE_PER_PROJECT_SETTINGS){
      return SearchUtil.lightOptions(this, myMainPanel, option, myGlassPanel);
    } else {
      return mySettingsPanel.showOption(this, option, myGlassPanel);
    }
  }
}