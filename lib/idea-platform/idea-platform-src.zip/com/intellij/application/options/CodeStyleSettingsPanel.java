package com.intellij.application.options;

import com.intellij.ide.ui.search.OptionDescription;
import com.intellij.ide.ui.search.SearchUtil;
import com.intellij.ide.ui.search.SearchableOptionsRegistrarImpl;
import com.intellij.openapi.application.ApplicationBundle;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.extensions.Extensions;
import com.intellij.openapi.fileTypes.FileTypes;
import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SearchableConfigurable;
import com.intellij.openapi.options.ex.GlassPanel;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import com.intellij.psi.codeStyle.CodeStyleSettingsProvider;
import com.intellij.ui.TabbedPaneWrapper;
import com.intellij.util.Alarm;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * @author max
 */
public class CodeStyleSettingsPanel extends JPanel {
  private static final Logger LOG = Logger.getInstance("#com.intellij.application.options.CodeStyleSettingsPanel");

  private Configurable[] myTabs;
  private TabbedPaneWrapper myTabbedPane;
  private CodeStyleSettings mySettings;
  private CodeStyleSettings myCloneSettings;

  public CodeStyleSettingsPanel(CodeStyleSettings settings) {
    super(new BorderLayout());
    mySettings = settings;
    myCloneSettings = (CodeStyleSettings)mySettings.clone();
  }

  public void selectTab(final Class configClass) {
    final Alarm alarm = new Alarm();
    final Runnable request = new Runnable() {
      public void run() {
        if (myTabs == null) {
          alarm.addRequest(this, 300, ModalityState.stateForComponent(CodeStyleSettingsPanel.this));
          return;
        }

        for (int i = 0; i < myTabs.length; i++) {
          Configurable tab = myTabs[i];
          if (configClass == tab.getClass()) {
            myTabbedPane.setSelectedIndex(i);
          }
        }
      }
    };
    // make sure CodeStyleConfigurable.selectScheme finished
    alarm.addRequest(request, 300, ModalityState.stateForComponent(this));
  }

  public boolean isModified() {
    if (myTabs == null) return false;
    for (Configurable tab : myTabs) {
      if (tab.isModified()) return true;
    }
    return false;
  }

  public CodeStyleSettings getSettings() { return mySettings; }

  public void init() {
    if (myTabs != null) return;


    List<Configurable> tabs = new ArrayList<Configurable>(Arrays.asList(
      new CodeStyleAbstractConfigurable(mySettings,myCloneSettings, ApplicationBundle.message("title.general")){
        protected CodeStyleAbstractPanel createPanel(final CodeStyleSettings settings) {
          return new GeneralCodeStylePanel(settings);
        }

        public Icon getIcon() {
          return FileTypes.PLAIN_TEXT.getIcon();
        }

        public String getHelpTopic() {
          return "reference.settingsdialog.IDE.globalcodestyle.general";
        }
      }
    ));

    for (final CodeStyleSettingsProvider provider : Extensions.getExtensions(CodeStyleSettingsProvider.EXTENSION_POINT_NAME)) {
      tabs.add(provider.createSettingsPage(mySettings, myCloneSettings));
    }

    myTabs = tabs.toArray(new Configurable[tabs.size()]);
    myTabbedPane = new TabbedPaneWrapper();
    for (Configurable tab : myTabs) {
      myTabbedPane.addTab(tab.getDisplayName(),
          tab.getIcon(),
          tab.createComponent(),
          null);
      tab.reset();
    }

    myTabbedPane.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateSelectedTab();
      }
    });

    add(myTabbedPane.getComponent(), BorderLayout.CENTER);
  }

  private void updateSelectedTab() {
    final int selectedIndex = myTabbedPane.getSelectedIndex();
    if (selectedIndex >= 0) {
      final Configurable selectedConfigurable = myTabs[selectedIndex];
      if (selectedConfigurable instanceof CodeStyleAbstractConfigurable) {
        ((CodeStyleAbstractConfigurable)selectedConfigurable).getPanel().updatePreview();
      }
    }
  }

  public void apply() {
    if (myTabs == null) return;
    try {
      for (Configurable tab : myTabs) {
        if (tab.isModified()) tab.apply();
      }
    }
    catch (ConfigurationException e) {
      LOG.error(e);
    }
  }

  @Nullable
  public String getHelpTopic() {
    int index = myTabbedPane.getSelectedIndex();
    return myTabs[index].getHelpTopic();
  }

  public void dispose() {
    if (myTabs != null) {
      for (Configurable tab : myTabs) {
        tab.disposeUIResources();
      }
    }
  }

  public void reset() {
    if (myTabs == null) return;
    for (Configurable tab : myTabs) {
      if (tab.isModified()) tab.reset();
    }
    updateSelectedTab();
  }

  @Nullable
  public Runnable showOption(SearchableConfigurable configurable, final String option, final GlassPanel glassPanel) {
    if (isInitialized()){
      final Runnable runnable = SearchUtil.lightOptions(configurable, myTabbedPane.getComponent(), option, glassPanel);
      String path = SearchableOptionsRegistrarImpl.getInstance().getInnerPath(configurable, option);
      if (path != null){
        if (path.indexOf('.') > -1){
          path = path.substring(0, path.indexOf('.'));
        }
        final String mainTab = path;
        return new Runnable() {
          public void run() {
            myTabbedPane.setSelectedIndex(SearchUtil.getSelection(mainTab, myTabbedPane));
            runnable.run();
          }
        };
      }
      return runnable;
    }
    return null;
  }

  public HashSet<OptionDescription> processOptions() {
    init();
    final HashSet<OptionDescription> options = new HashSet<OptionDescription>();
    SearchUtil.processComponent(myTabbedPane.getComponent(), options, null);
    return options;
  }

  public boolean isInitialized(){
    return myTabbedPane != null;
  }
}
