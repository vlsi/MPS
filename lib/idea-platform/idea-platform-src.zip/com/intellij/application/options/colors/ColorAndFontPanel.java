package com.intellij.application.options.colors;

import com.intellij.application.options.SaveSchemeDialog;
import com.intellij.application.options.SelectFontDialog;
import com.intellij.application.options.colors.highlighting.HighlightData;
import com.intellij.application.options.colors.highlighting.HighlightsExtractor;
import com.intellij.codeInsight.daemon.impl.TrafficLightRenderer;
import com.intellij.ide.DataManager;
import com.intellij.ide.highlighter.HighlighterFactory;
import com.intellij.ide.ui.search.SearchUtil;
import com.intellij.ide.ui.search.SearchableOptionsRegistrar;
import com.intellij.ide.util.scopeChooser.ScopeChooserConfigurable;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.application.ApplicationBundle;
import com.intellij.openapi.diff.impl.settings.DiffColorsForm;
import com.intellij.openapi.editor.*;
import com.intellij.openapi.editor.colors.CodeInsightColors;
import com.intellij.openapi.editor.colors.EditorColorsManager;
import com.intellij.openapi.editor.colors.EditorColorsScheme;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.editor.ex.EditorEx;
import com.intellij.openapi.editor.ex.EditorMarkupModel;
import com.intellij.openapi.editor.ex.EditorSettingsExternalizable;
import com.intellij.openapi.editor.highlighter.EditorHighlighter;
import com.intellij.openapi.editor.highlighter.HighlighterIterator;
import com.intellij.openapi.editor.markup.ErrorStripeRenderer;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.options.SearchableConfigurable;
import com.intellij.openapi.options.ShowSettingsUtil;
import com.intellij.openapi.options.colors.AttributesDescriptor;
import com.intellij.openapi.options.colors.ColorSettingsPage;
import com.intellij.openapi.options.colors.ColorSettingsPages;
import com.intellij.openapi.options.colors.EditorHighlightingProvidingColorSettingsPage;
import com.intellij.openapi.options.ex.GlassPanel;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;
import com.intellij.openapi.ui.FixedSizeButton;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.FileStatusFactory;
import com.intellij.psi.tree.IElementType;
import com.intellij.ui.DocumentAdapter;
import com.intellij.ui.IdeBorderFactory;
import com.intellij.ui.ListScrollingUtil;
import com.intellij.ui.TabbedPaneWrapper;
import com.intellij.util.Alarm;
import com.intellij.util.containers.HashMap;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class ColorAndFontPanel extends JPanel {
  private ColorAndFontOptions myOptions;

  private JTextField myEditorFontSizeField;

  private JTextField myLineSpacingField;
  private JTextField myFontNameField;
  private JComboBox mySchemeComboBox;

  private static ArrayList<String> myFontNamesVector;
  private static HashMap<String, Boolean> myFontNameToIsMonospaced;
  private JButton myDeleteButton;
  private boolean myListLoaded;

  private Map<ColorSettingsPage, HighlightData[]> myHighlightData = new HashMap<ColorSettingsPage, HighlightData[]>();
  private TabbedPaneWrapper myTabbedPane;
  private DiffColorsForm myDiffColorsForm;

  private boolean myIsInSchemeChange;
  private Map<ColorSettingsPage, Editor> myEditors = new HashMap<ColorSettingsPage, Editor>();
  private Map<ColorSettingsPage, Alarm> myBlinkingAlarms = new HashMap<ColorSettingsPage, Alarm>();
  private GlassPanel myGlassPanel;

  public ColorAndFontPanel(ColorAndFontOptions options) {
    super(new BorderLayout());
    myOptions = options;

    JPanel schemesGroup = new JPanel(new BorderLayout());

    JPanel panel = new JPanel(new BorderLayout());
    panel.add(createFontPanel(), BorderLayout.NORTH);
    panel.add(createEditorPanel(), BorderLayout.CENTER);
    schemesGroup.add(createSchemePanel(), BorderLayout.NORTH);
    schemesGroup.add(panel, BorderLayout.CENTER);
    add(schemesGroup, BorderLayout.CENTER);

    mySchemeComboBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (mySchemeComboBox.getSelectedIndex() != -1) {
          EditorColorsScheme selected = myOptions.selectScheme((String)mySchemeComboBox.getSelectedItem());
          if (ColorAndFontOptions.isDefault(selected)) {
            myDeleteButton.setEnabled(false);
          }
          else {
            myDeleteButton.setEnabled(true);
          }

          if (myListLoaded) {
            changeToScheme(selected);
          }
        }
      }
    });
    myGlassPanel = new GlassPanel(this);
  }

  public void dispose() {
    EditorFactory editorFactory = EditorFactory.getInstance();
    for (final Editor editor : myEditors.values()) {
      editorFactory.releaseEditor(editor);
    }
    stopBlinking();
  }

  private void updateHighlighters(EditorColorsScheme scheme) {
    myDiffColorsForm.setColorScheme(scheme);

    for (ColorSettingsPage page : myEditors.keySet()) {
      EditorHighlighter highlighter = null;
      if (page instanceof EditorHighlightingProvidingColorSettingsPage) {
        highlighter = ((EditorHighlightingProvidingColorSettingsPage)page).createEditorHighlighter(scheme);
      }
      if (highlighter == null) {
        final SyntaxHighlighter pageHighlighter = page.getHighlighter();
        highlighter = HighlighterFactory.createHighlighter(pageHighlighter, scheme);
      }
      ((EditorEx)myEditors.get(page)).setHighlighter(highlighter);
      updateHighlighters(page);
    }
  }

  private ColorAndFontDescriptionPanel createListAndSettingsPanel() {
    ColorAndFontDescriptionPanel descriptionPanel = new ColorAndFontDescriptionPanel();
    descriptionPanel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        updateDescription(true);
      }
    });
    return descriptionPanel;
  }

  public Runnable showOption(final SearchableConfigurable configurable, final String option, final boolean highlight) {
    final Runnable runnable = SearchUtil.lightOptions(configurable, this, option, myGlassPanel);
    final @NonNls String path = SearchableOptionsRegistrar.getInstance().getInnerPath(configurable, option);
    if (path != null){
      return new Runnable() {
        public void run() {
          final int selection = SearchUtil.getSelection(path, myTabbedPane);
          myTabbedPane.setSelectedIndex(selection);
          if (myTabbedPane.getSelectedComponent() instanceof MyTab) {
            MyTab tab = (MyTab)myTabbedPane.getSelectedComponent();
            final JList list = tab.getOptionsList();
            final AbstractListModel listModel = (AbstractListModel)list.getModel();
            if (!selectItem(listModel, list, option, true, configurable, highlight)){
              selectItem(listModel, list, option, false, configurable, highlight);
            }
          }
        }
      };
    }
    return runnable;
  }

  private boolean selectItem(final AbstractListModel listModel,
                             final JList list,
                             final String option,
                             boolean forceSelect,
                             final SearchableConfigurable configurable,
                             boolean highlight) {
    for(int i = 0; i < listModel.getSize(); i++){
      String descriptor = listModel.getElementAt(i).toString().toLowerCase();
      if (SearchUtil.isComponentHighlighted(descriptor, option, forceSelect, configurable)){
        ListScrollingUtil.selectItem(list, i);
        if (highlight) {
          SearchUtil.lightOptions(configurable, this, option, myGlassPanel, forceSelect).run();
        }
        return true;
      }
    }
    return false;
  }

  public void clearSearch() {
    myGlassPanel.clear();
  }

  public Map<String, String> processListOptions() {
    final Map<String, String> result = new HashMap<String, String>();
    final ColorSettingsPage[] colorSettingsPages = ColorSettingsPages.getInstance().getRegisteredPages();
    for (ColorSettingsPage colorSettingsPage : colorSettingsPages) {
      final AttributesDescriptor[] attributesDescriptors = colorSettingsPage.getAttributeDescriptors();
      for (AttributesDescriptor descriptor : attributesDescriptors) {
        result.put(descriptor.getDisplayName(), colorSettingsPage.getDisplayName());
      }
    }
    MyTab diffTab = (MyTab)myDiffColorsForm.getComponent();
    JList list = diffTab.getOptionsList();
    AbstractListModel model = (AbstractListModel)list.getModel();
    for(int i = 0; i < model.getSize(); i++){
      result.put(model.getElementAt(i).toString(), ColorAndFontOptions.DIFF_GROUP);
    }
    final FileStatus[] fileStatuses = FileStatusFactory.SERVICE.getInstance().getAllFileStatuses();
    for (FileStatus fileStatus : fileStatuses) {
      result.put(fileStatus.getText(), ColorAndFontOptions.FILE_STATUS_GROUP);
    }
    return result;
  }

  public interface MyTab {
    void processListValueChanged();

    void updateDescription(ColorAndFontOptions options);

    void fillOptionsList(ColorAndFontOptions options, String category);

    JList getOptionsList();
  }

  private class MyTabImpl extends JPanel implements MyTab {
    private JList myOptionsList;
    private ColorAndFontDescriptionPanel myOptionsPanel;

    public MyTabImpl(JComponent southComponent, ColorAndFontDescriptionPanel optionsPanel) {
      super(new BorderLayout());

      myOptionsList = new JList();

      myOptionsList.addListSelectionListener(new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
          if (!myListLoaded) return;
          ColorAndFontPanel.this.processListValueChanged(null);
        }
      });
      myOptionsList.setCellRenderer(new DefaultListCellRenderer(){
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
          Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
          if (value instanceof ColorAndFontDescription) {
            setIcon(((ColorAndFontDescription)value).getIcon());
            setToolTipText(((ColorAndFontDescription)value).getToolTip());
          }
          return component;
        }
      });

      myOptionsList.setModel(new DefaultListModel());
      myOptionsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      JScrollPane scrollPane = new JScrollPane(myOptionsList);
      scrollPane.setPreferredSize(new Dimension(230, 60));
      JPanel north = new JPanel(new BorderLayout());
      north.add(scrollPane, BorderLayout.WEST);
      north.add(optionsPanel, BorderLayout.CENTER);
      myOptionsPanel = optionsPanel;
      add(north, BorderLayout.NORTH);
      add(southComponent, BorderLayout.CENTER);
    }

    public void processListValueChanged() {
      ColorAndFontDescription description = (ColorAndFontDescription)myOptionsList.getSelectedValue();
      ColorAndFontDescriptionPanel optionsPanel = myOptionsPanel;
      if (description == null) {
        optionsPanel.resetDefault();
        return;
      }
      optionsPanel.reset(description);
    }

    public void updateDescription(ColorAndFontOptions options) {
      ColorAndFontDescription description = (ColorAndFontDescription)myOptionsList.getSelectedValue();

      EditorColorsScheme scheme = options.getSelectedScheme();
      myOptionsPanel.apply(description,scheme);
    }

    public void fillOptionsList(ColorAndFontOptions options, String category) {
      JList optionsList = myOptionsList;

      DefaultListModel listModel = (DefaultListModel)optionsList.getModel();
      listModel.removeAllElements();

      EditorSchemeAttributeDescriptor[] descriptions = options.getCurrentDescriptions();

      for (EditorSchemeAttributeDescriptor description : descriptions) {
        if (description.getGroup().equals(category)) {
          listModel.addElement(description);
        }
      }
      ListScrollingUtil.ensureSelectionExists(optionsList);
    }

    public JList getOptionsList() {
      return myOptionsList;
    }
  }

  private MyTabImpl createTab(JComponent southComponent) {
    return new MyTabImpl(southComponent, createListAndSettingsPanel());
  }

  private Component createEditorPanel() {
    myTabbedPane = new TabbedPaneWrapper(SwingConstants.TOP) {
      protected TabbedPane createTabbedPane(int tabPlacement) {
        return new TabbedPane(tabPlacement) {
          public Dimension getPreferredSize() {
            Dimension size = super.getPreferredSize();
            size.height = 0;
            return size;
          }
        };
      }
    };

    initPluggedTabs();
    initDiffTab();
    initFileStatusTab();
    initScopeTab();

    updateHighlighters((EditorColorsScheme)EditorColorsManager.getInstance().getGlobalScheme().clone());
    reinitViews();

    return myTabbedPane.getComponent();
  }

  private void initPluggedTabs() {
    ColorSettingsPage[] pages = ColorSettingsPages.getInstance().getRegisteredPages();
    for (ColorSettingsPage page : pages) {
      initTab(page);
    }
  }

  @Nullable
  public JComponent getPreferedFocusComponent() {
    JComponent selectedComponent = myTabbedPane.getSelectedComponent();
    if (selectedComponent == null) return null;
    Container focusCycleRoot = selectedComponent.isFocusCycleRoot() ? selectedComponent : selectedComponent.getFocusCycleRootAncestor();
    return safeCast(focusCycleRoot.getFocusTraversalPolicy().getDefaultComponent(focusCycleRoot), JComponent.class);
  }

  @Nullable
  @SuppressWarnings({"unchecked"})
  public static <T> T safeCast(final Object obj, final Class<T> expectedClass) {
    if (expectedClass.isInstance(obj)) return (T)obj;
    return null;
  }

  private void initFileStatusTab() {
    myTabbedPane.addTab(ColorAndFontOptions.FILE_STATUS_GROUP,
                        IconLoader.getIcon("/actions/fileStatus.png"),
                        createTab(new JPanel()),
                        null);
  }

  private void initDiffTab() {
    JComponent diffTab = createDiffTab();
    myTabbedPane.addTab(ColorAndFontOptions.DIFF_GROUP, IconLoader.getIcon("/diff/Diff.png"), diffTab, null);
  }
  private void initScopeTab() {
    JPanel panel = createChooseScopePanel();
    myTabbedPane.addTab(ColorAndFontOptions.SCOPES_GROUP,
                        StdFileTypes.JAVA.getIcon(),
                        createTab(panel),
                        null);
  }

  private JPanel createChooseScopePanel() {
    Project[] projects = ProjectManager.getInstance().getOpenProjects();
    JPanel panel = new JPanel(new GridBagLayout());
    //panel.setBorder(new LineBorder(Color.red));
    if (projects.length == 0) return panel;
    GridBagConstraints gc = new GridBagConstraints(0, 0, 1, 1, 0, 0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE,
                                                   new Insets(0, 0, 0, 0), 0, 0);
    final Project contextProject = PlatformDataKeys.PROJECT.getData(DataManager.getInstance().getDataContext());
    final Project project = contextProject != null ? contextProject : projects[0];

    JButton button = new JButton(ApplicationBundle.message("button.edit.scopes"));
    button.setPreferredSize(new Dimension(230, button.getPreferredSize().height));
    panel.add(button, gc);
    gc.gridx = GridBagConstraints.REMAINDER;
    gc.weightx = 1;
    panel.add(new JPanel(), gc);

    gc.gridy++;
    gc.gridx=0;
    gc.weighty = 1;
    panel.add(new JPanel(), gc);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        final ScopeChooserConfigurable configurable = ScopeChooserConfigurable.getInstance(project);
        final boolean isOk = ShowSettingsUtil.getInstance().editConfigurable(project, configurable);
        if (isOk) {
          myOptions.reset();
        }
      }
    });
    return panel;
  }

  private void initTab(ColorSettingsPage page) {
    String text = page.getDemoText();

    HighlightsExtractor extractant2 = new HighlightsExtractor(page.getAdditionalHighlightingTagToDescriptorMap());
    HighlightData[] highlightData = extractant2.extractHighlights(text);
    myHighlightData.put(page, highlightData);

    Editor editor = createEditor(extractant2.cutDefinedTags(text), 10, 3, -1);

    ErrorStripeRenderer renderer = new TrafficLightRenderer(null,null,null,null){
      protected DaemonCodeAnalyzerStatus getDaemonCodeAnalyzerStatus() {
        DaemonCodeAnalyzerStatus status = new DaemonCodeAnalyzerStatus();
        status.errorAnalyzingFinished = true;
        status.passStati = new ArrayList<DaemonCodeAnalyzerStatus.PassStatus>();
        status.errorCount = new int[]{1, 2};
        return status;
      }
    };
    ((EditorMarkupModel)editor.getMarkupModel()).setErrorStripeRenderer(renderer);
    ((EditorMarkupModel)editor.getMarkupModel()).setErrorStripeVisible(true);
    myEditors.put(page, editor);
    myBlinkingAlarms.put(page, new Alarm());

    MyTabImpl tab = createTab(editor.getComponent());
    new ClickNavigator(tab.myOptionsList).addClickNavigator(editor,
                                                            page.getHighlighter(),
                                                            highlightData,
                                                            false
    );

    myTabbedPane.addTab(page.getDisplayName(), page.getIcon(), tab, null);
  }

  private JComponent createDiffTab() {
    myDiffColorsForm = new DiffColorsForm();

    myDiffColorsForm.setMergeRequest(null);
    return myDiffColorsForm.getComponent();
  }

  private Editor createEditor(String text, int column, int line, int selectedLine) {
    EditorFactory editorFactory = EditorFactory.getInstance();
    Document editorDocument = editorFactory.createDocument(text);
    EditorEx editor = (EditorEx)editorFactory.createViewer(editorDocument);
    editor.setColorsScheme(getCurrentScheme());
    EditorSettings settings = editor.getSettings();
    settings.setLineNumbersShown(true);
    settings.setWhitespacesShown(true);
    settings.setLineMarkerAreaShown(false);
    settings.setFoldingOutlineShown(false);
    settings.setAdditionalColumnsCount(0);
    settings.setAdditionalLinesCount(0);
    settings.setRightMarginShown(true);
    settings.setRightMargin(60);

    LogicalPosition pos = new LogicalPosition(line, column);
    editor.getCaretModel().moveToLogicalPosition(pos);
    if (selectedLine >= 0) {
      editor.getSelectionModel().setSelection(editorDocument.getLineStartOffset(selectedLine),
                                              editorDocument.getLineEndOffset(selectedLine));
    }

    return editor;
  }

  private EditorColorsScheme getCurrentScheme() {
    return myOptions.getSelectedScheme();
  }

  private JPanel createFontPanel() {
    JPanel editorFontPanel = new JPanel();
    editorFontPanel.setBorder(IdeBorderFactory.createTitledBorder(ApplicationBundle.message("group.editor.font")));
    editorFontPanel.setLayout(new GridBagLayout());
    GridBagConstraints gbConstraints = new GridBagConstraints();
    gbConstraints.fill = GridBagConstraints.HORIZONTAL;
    gbConstraints.weightx = 0;
    gbConstraints.weighty = 1;
    gbConstraints.gridx = 0;
    gbConstraints.gridy = 0;
    gbConstraints.gridwidth = 1;

    gbConstraints.insets = new Insets(0, 0, 0, 0);
    gbConstraints.gridwidth = 1;
    editorFontPanel.add(new JLabel(ApplicationBundle.message("label.font.name")), gbConstraints);

    myFontNameField = new MyTextField(20);
    myFontNameField.setEditable(false);
    myFontNameField.setFocusable(false);

    gbConstraints.gridx = 1;
    gbConstraints.insets = new Insets(0, 0, 0, 2);
    editorFontPanel.add(myFontNameField, gbConstraints);

    JButton myFontNameButton = new FixedSizeButton(myFontNameField);
    gbConstraints.gridx = 2;
    gbConstraints.insets = new Insets(0, 0, 0, 8);
    editorFontPanel.add(myFontNameButton, gbConstraints);

    gbConstraints.gridx = 3;
    gbConstraints.insets = new Insets(0, 0, 0, 0);
    editorFontPanel.add(new JLabel(ApplicationBundle.message("editbox.font.size")), gbConstraints);
    gbConstraints.gridx = 4;
    gbConstraints.insets = new Insets(0, 0, 0, 8);
    myEditorFontSizeField = new MyTextField(4);
    gbConstraints.gridx = 5;
    editorFontPanel.add(myEditorFontSizeField, gbConstraints);
    gbConstraints.insets = new Insets(0, 0, 0, 0);
    gbConstraints.gridx = 6;
    editorFontPanel.add(new JLabel(ApplicationBundle.message("editbox.line.spacing")), gbConstraints);
    gbConstraints.insets = new Insets(0, 0, 0, 0);
    gbConstraints.gridx = 7;
    myLineSpacingField = new MyTextField(4);
    editorFontPanel.add(myLineSpacingField, gbConstraints);
    gbConstraints.weightx = 1;
    gbConstraints.gridx = 8;
    editorFontPanel.add(new TailPanel(), gbConstraints);

    myFontNameButton.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (ColorAndFontOptions.isDefault(getCurrentScheme())) {
            showReadOnlyMessage(ColorAndFontPanel.this);
            return;
          }

          selectFont();
        }
      }
    );

    myEditorFontSizeField.getDocument().addDocumentListener(new DocumentAdapter() {
      public void textChanged(DocumentEvent event) {
        if (myIsInSchemeChange) return;
        int fontSize = 12;
        try {
          fontSize = Integer.parseInt(myEditorFontSizeField.getText());
        }
        catch (NumberFormatException e) {
          // OK, ignore
        }
        finally {
          if (fontSize < 1) fontSize = 1;
          if (fontSize > 30) fontSize = 30;

          getCurrentScheme().setEditorFontSize(fontSize);
          updateDescription(true);
        }
      }
    });

    myLineSpacingField.getDocument().addDocumentListener(new DocumentAdapter() {
      public void textChanged(DocumentEvent event) {
        if (myIsInSchemeChange) return;
        float lineSpacing = 1;
        try {
          lineSpacing = Float.parseFloat(myLineSpacingField.getText());
        }
        catch (NumberFormatException e) {
          // OK, ignore
        }
        finally {
          if (lineSpacing <= 0) lineSpacing = 1;
          if (lineSpacing > 30) lineSpacing = 30;
          if (getCurrentScheme().getLineSpacing() != lineSpacing) {
            getCurrentScheme().setLineSpacing(lineSpacing);
          }
          updateDescription(true);
        }
      }
    });

    return editorFontPanel;
  }

  public static void showReadOnlyMessage(JComponent parent) {
    Messages.showMessageDialog(
      parent,
      ApplicationBundle.message("error.default.scheme.cannot.be.modified"),
      ApplicationBundle.message("title.cannot.modify.default.scheme"),
      Messages.getInformationIcon()
    );
  }

  private JPanel createSchemePanel() {
    JPanel panel = new JPanel(new GridBagLayout());

    panel.add(new JLabel(ApplicationBundle.message("combobox.scheme.name")),
              new GridBagConstraints(0, 0, 1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                                     new Insets(5, 5, 5, 5), 0, 0));

    mySchemeComboBox = new JComboBox();
    panel.add(mySchemeComboBox,
              new GridBagConstraints(1, 0, 1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                                     new Insets(5, 0, 5, 5), 0, 0));

    JButton saveAsButton = new JButton(ApplicationBundle.message("button.save.as"));
    saveAsButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        showSaveAsDialog();
      }
    });
    panel.add(saveAsButton,
              new GridBagConstraints(2, 0, 1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                                     new Insets(5, 0, 5, 5), 0, 0));

    myDeleteButton = new JButton(ApplicationBundle.message("button.delete"));
    myDeleteButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (mySchemeComboBox.getSelectedIndex() != -1) {
          myOptions.removeScheme((String)mySchemeComboBox.getSelectedItem());
        }
      }
    });
    panel.add(myDeleteButton,
              new GridBagConstraints(3, 0, 1, 1, 1, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                                     new Insets(5, 0, 5, 5), 0, 0));

    return panel;
  }

  private void showSaveAsDialog() {
    ArrayList<String> names = new ArrayList<String>();
    EditorColorsScheme[] allSchemes = EditorColorsManager.getInstance().getAllSchemes();

    for (EditorColorsScheme scheme : allSchemes) {
      names.add(scheme.getName());
    }

    SaveSchemeDialog dialog = new SaveSchemeDialog(this, ApplicationBundle.message("title.save.color.scheme.as"), names);
    dialog.show();
    if (dialog.isOK()) {
      myOptions.saveSchemeAs(dialog.getSchemeName());
      changeToScheme(myOptions.getSelectedScheme());
      resetSchemesCombo();
    }
  }

  private void selectFont() {
    initFontTables();

    List<String> fontNamesVector = (List<String>)myFontNamesVector.clone();
    HashMap fontNameToIsMonospaced = (HashMap)myFontNameToIsMonospaced.clone();
    String initialFontName = myFontNameField.getText();
    if (!fontNamesVector.contains(EditorSettingsExternalizable.DEFAULT_FONT_NAME)) {
      fontNamesVector.add(0, EditorSettingsExternalizable.DEFAULT_FONT_NAME);
    }
    if (!fontNamesVector.contains(initialFontName)) {
      fontNamesVector.add(0, initialFontName);
    }
    SelectFontDialog selectFontDialog = new SelectFontDialog(this, fontNamesVector, initialFontName,
                                                             fontNameToIsMonospaced);
    selectFontDialog.show();
    if (!selectFontDialog.isOK()) {
      return;
    }
    String fontName = selectFontDialog.getFontName();
    if (fontName != null) {
      myFontNameField.setText(fontName);
      getCurrentScheme().setEditorFontName(fontName);
      updateDescription(true);
    }
  }

  @SuppressWarnings({"AssignmentToStaticFieldFromInstanceMethod"})
  private void initFontTables() {
    if (myFontNamesVector == null) {
      myFontNamesVector = new ArrayList<String>();
      myFontNameToIsMonospaced = new HashMap<String, Boolean>();

      ProgressManager.getInstance().runProcessWithProgressSynchronously(new InitFontsRunnable(), ApplicationBundle.message("progress.analyzing.fonts"), false, null);
    }
  }

  public void changeToScheme(EditorColorsScheme scheme) {
    myIsInSchemeChange = true;

    for (Editor e : myEditors.values()) {
      ((EditorEx)e).setColorsScheme(getCurrentScheme());
    }

    myDiffColorsForm.setScheme(getCurrentScheme(), ColorAndFontOptions.isDefault(scheme));
    myLineSpacingField.setText(Float.toString(getCurrentScheme().getLineSpacing()));
    myEditorFontSizeField.setText(Integer.toString(getCurrentScheme().getEditorFontSize()));
    myFontNameField.setText(getCurrentScheme().getEditorFontName());

    if (ColorAndFontOptions.isDefault(scheme)) {
      myLineSpacingField.setEnabled(false);
      myEditorFontSizeField.setEditable(false);
      myFontNameField.setEnabled(false);
    }
    else {
      myLineSpacingField.setEnabled(true);
      myEditorFontSizeField.setEditable(true);
      myFontNameField.setEnabled(true);
    }

    fillList();
    myIsInSchemeChange = false;

    updateDescription(false);
  }

  private void updateDescription(boolean modified) {
    MyTab selectedTab = (MyTab)myTabbedPane.getSelectedComponent();
    EditorColorsScheme scheme = myOptions.getSelectedScheme();

    if (modified && ColorAndFontOptions.isDefault(scheme)) {
      showReadOnlyMessage(this);
      processListValueChanged(null);
      return;
    }

    selectedTab.updateDescription(myOptions);

    updateHighlighters(scheme);
    reinitViews();
  }

  private void updateHighlighters(ColorSettingsPage page) {
    Editor editor = myEditors.get(page);
    HighlightData[] datum = myHighlightData.get(page);
    final Map<TextAttributesKey, String> displayText = keyToDisplayTextMap(page);
    for (final HighlightData data : datum) {
      data.addHighlToView(editor, getCurrentScheme(), displayText);
    }
  }

  private static Map<TextAttributesKey, String> keyToDisplayTextMap(final ColorSettingsPage page) {
    final AttributesDescriptor[] attributeDescriptors = page.getAttributeDescriptors();
    final Map<TextAttributesKey, String> displayText = new HashMap<TextAttributesKey, String>();
    for (AttributesDescriptor attributeDescriptor : attributeDescriptors) {
      final TextAttributesKey key = attributeDescriptor.getKey();
      displayText.put(key, attributeDescriptor.getDisplayName());
    }
    return displayText;
  }

  private void reinitViews() {
    for (final Editor editor : myEditors.values()) {
      EditorEx e = (EditorEx)editor;
      e.reinitSettings();
    }
  }

  private void processListValueChanged(MyTab tab) {
    MyTab toProcess = tab;
    if (toProcess == null) {
      final JComponent selected = myTabbedPane.getSelectedComponent();
      if (selected instanceof MyTab) {
        toProcess = (MyTab)selected;
      }
    }

    if (toProcess == null) return;
    
    toProcess.processListValueChanged();
    blinkSelectedHighlightType();
  }

  private static final int BLINK_COUNT = 3 * 2;

  private void blinkSelectedHighlightType() {
    JComponent selectedTab = myTabbedPane.getSelectedComponent();
    if (!(selectedTab instanceof MyTabImpl)) return;
    MyTabImpl tab = (MyTabImpl) selectedTab;
    EditorSchemeAttributeDescriptor description = getSelectedDescription(tab);
    if (description == null) return;
    String type = description.getType();

    for (ColorSettingsPage page : myEditors.keySet()) {
      List<HighlightData> highlights = startBlinkingHighlights((EditorEx)myEditors.get(page), myHighlightData.get(page), type,
                                                               page.getHighlighter(), true, myBlinkingAlarms.get(page), BLINK_COUNT, page);
      scrollHighlightInView(highlights, type, myEditors.get(page));
    }
  }

  private static void scrollHighlightInView(final List<HighlightData> highlightDatas, final String type, final Editor editor) {
    boolean needScroll = true;
    int minOffset = Integer.MAX_VALUE;
    for(HighlightData data: highlightDatas) {
      if (isOffsetVisible(editor, data.getStartOffset())) {
        needScroll = false;
        break;
      }
      minOffset = Math.min(minOffset, data.getStartOffset());
    }
    if (needScroll && minOffset != Integer.MAX_VALUE) {
      LogicalPosition pos = editor.offsetToLogicalPosition(minOffset);
      editor.getScrollingModel().scrollTo(pos, ScrollType.MAKE_VISIBLE);
    }
  }

  private static boolean isOffsetVisible(final Editor editor, final int startOffset) {
    Rectangle visibleArea = editor.getScrollingModel().getVisibleArea();
    Point point = editor.logicalPositionToXY(editor.offsetToLogicalPosition(startOffset));
    return point.y >= visibleArea.y && point.y < visibleArea.x + visibleArea.height;
  }

  private void stopBlinking() {
    for (Alarm alarm : myBlinkingAlarms.values()) {
      alarm.cancelAllRequests();
    }
  }

  private List<HighlightData> startBlinkingHighlights(final EditorEx editor,
                                                      final HighlightData[] highlightDatum,
                                                      final String attrKey,
                                                      final SyntaxHighlighter highlighter,
                                                      final boolean show,
                                                      final Alarm alarm,
                                                      final int count,
                                                      final ColorSettingsPage page) {
    if (show && count <= 0) return Collections.emptyList();
    editor.getMarkupModel().removeAllHighlighters();
    boolean found = false;
    List<HighlightData> highlights = new ArrayList<HighlightData>();
    List<HighlightData> matchingHighlights = new ArrayList<HighlightData>();
    for (int i = 0; highlightDatum != null && i < highlightDatum.length; i++) {
      HighlightData highlightData = highlightDatum[i];
      String type = highlightData.getHighlightType();
      highlights.add(highlightData);
      if (show && type.equals(attrKey)) {
        highlightData =
        new HighlightData(highlightData.getStartOffset(), highlightData.getEndOffset(),
                          CodeInsightColors.BLINKING_HIGHLIGHTS_ATTRIBUTES);
        highlights.add(highlightData);
        matchingHighlights.add(highlightData);
        found = true;
      }
    }
    if (!found && highlighter != null) {
      HighlighterIterator iterator = editor.getHighlighter().createIterator(0);
      do {
        IElementType tokenType = iterator.getTokenType();
        TextAttributesKey[] tokenHighlights = highlighter.getTokenHighlights(tokenType);
        for (final TextAttributesKey tokenHighlight : tokenHighlights) {
          String type = tokenHighlight.getExternalName();
          if (show && type != null && type.equals(attrKey)) {
            HighlightData highlightData = new HighlightData(iterator.getStart(), iterator.getEnd(),
                                                            CodeInsightColors.BLINKING_HIGHLIGHTS_ATTRIBUTES);
            highlights.add(highlightData);
            matchingHighlights.add(highlightData);
          }
        }
        iterator.advance();
      }
      while (!iterator.atEnd());
    }

    final Map<TextAttributesKey, String> displayText = keyToDisplayTextMap(page);

    // sort highlights to avoid overlappings
    Collections.sort(highlights, new Comparator<HighlightData>() {
      public int compare(HighlightData highlightData1, HighlightData highlightData2) {
        return highlightData1.getStartOffset() - highlightData2.getStartOffset();
      }
    });
    for (int i = highlights.size() - 1; i >= 0; i--) {
      HighlightData highlightData = highlights.get(i);
      int startOffset = highlightData.getStartOffset();
      HighlightData prevHighlightData = i == 0 ? null : highlights.get(i - 1);
      if (prevHighlightData != null
          && startOffset <= prevHighlightData.getEndOffset()
          && highlightData.getHighlightType().equals(prevHighlightData.getHighlightType())) {
        prevHighlightData.setEndOffset(highlightData.getEndOffset());
      }
      else {
        highlightData.addHighlToView(editor, getCurrentScheme(), displayText);
      }
    }
    alarm.cancelAllRequests();
    alarm.addRequest(new Runnable() {
      public void run() {
        startBlinkingHighlights(editor, highlightDatum, attrKey, highlighter, !show, alarm, count - 1, page);
      }
    }, 400);
    return matchingHighlights;
  }

  private EditorSchemeAttributeDescriptor getSelectedDescription(MyTabImpl tab) {
    if (tab == null) tab = (MyTabImpl) myTabbedPane.getSelectedComponent();
    return (EditorSchemeAttributeDescriptor)tab.myOptionsList.getSelectedValue();
  }


  public void reset() {
    getRootPane().setGlassPane(myGlassPanel);
    myIsInSchemeChange = true;
    myFontNameField.setText(getCurrentScheme().getEditorFontName());
    myEditorFontSizeField.setText(Integer.toString(getCurrentScheme().getEditorFontSize()));
    myLineSpacingField.setText(Float.toString(getCurrentScheme().getLineSpacing()));
    myIsInSchemeChange = false;

    resetSchemesCombo();

    changeToScheme(getCurrentScheme());
  }

  public void apply() {
    changeToScheme(myOptions.getSelectedScheme());
  }

  public void resetSchemesCombo() {

    myListLoaded = false;

    String selectedSchemeBackup = myOptions.getSelectedScheme().getName();
    mySchemeComboBox.removeAllItems();

    String[] schemeNames = myOptions.getSchemeNames();
    for (String schemeName : schemeNames) {
      mySchemeComboBox.addItem(schemeName);
    }

    mySchemeComboBox.setSelectedItem(selectedSchemeBackup);
    fillList();
    myListLoaded = true;
  }

  private void fillList() {
    ArrayList<String> categories = new ArrayList<String>();
    ColorSettingsPage[] pages = ColorSettingsPages.getInstance().getRegisteredPages();
    for (ColorSettingsPage page : pages) {
      categories.add(page.getDisplayName());
    }
    categories.add(ColorAndFontOptions.DIFF_GROUP);
    categories.add(ColorAndFontOptions.FILE_STATUS_GROUP);
    categories.add(ColorAndFontOptions.SCOPES_GROUP);
    for (int i = 0; i < categories.size(); i++) {
      String category = categories.get(i);
      MyTab selectedTab = (MyTab)myTabbedPane.getComponentAt(i);
      selectedTab.fillOptionsList(myOptions, category);
      processListValueChanged(selectedTab);
    }
  }

  private class InitFontsRunnable implements Runnable {
    public void run() {
      ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();

      GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
      String[] fontNames = graphicsEnvironment.getAvailableFontFamilyNames();
      for (final String fontName : fontNames) {
        //noinspection HardCodedStringLiteral
        if (fontName.endsWith(".bold") || fontName.endsWith(".italic")) {
          continue;
        }
        try {
          Font plainFont = new Font(fontName, Font.PLAIN, 12);
          if (plainFont.canDisplay('W')) {
            Font boldFont = plainFont.deriveFont(Font.BOLD);
            if (progress != null) {
              progress.setText(ApplicationBundle.message("progress.analysing.font", fontName));
            }
            FontMetrics plainMetrics = getFontMetrics(plainFont);
            FontMetrics boldMetrics = getFontMetrics(boldFont);
            myFontNamesVector.add(fontName);
            int plainL = plainMetrics.charWidth('l');
            int boldL = boldMetrics.charWidth('l');
            int plainW = plainMetrics.charWidth('W');
            int boldW = boldMetrics.charWidth('W');
            int plainSpace = plainMetrics.charWidth(' ');
            int boldSpace = boldMetrics.charWidth(' ');
            boolean isMonospaced = plainL == plainW && plainL == boldL && plainW == boldW && plainSpace == boldSpace;
            myFontNameToIsMonospaced.put(fontName, isMonospaced);
          }
        }
        catch (Throwable e) {
          // JRE has problems working with the font. Just skip.
        }
      }
    }
  }

  private static class MyTextField extends JTextField {
    public MyTextField(int size) {
      super(size);
    }

    public Dimension getMinimumSize() {
      return super.getPreferredSize();
    }
  }
}
