/**
 * @author cdr
 */
package com.intellij.application.options.colors;

import javax.swing.*;
import java.awt.*;

class TailPanel extends JPanel {
  public Dimension getMinimumSize() {
    return new Dimension(0, 0);
  }
}