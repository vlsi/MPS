package com.incors.plaf.alloy;

import com.incors.plaf.alloy.themes.custom.CustomThemeFactory;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.SystemInfo;
import com.sun.java.swing.plaf.windows.WindowsTreeUI;

import javax.swing.*;
import java.awt.*;

import org.jetbrains.annotations.NotNull;

/**
 * @author max
 */
public class AlloyIdea extends IdeaAlloyLAF {
  private static final Logger LOG = Logger.getInstance("#com.incors.plaf.alloy.AlloyIdea");
  public static final String NAME = "Alloy. IDEA Theme";

  public AlloyIdea() {
    super(createNativeTheme(createNativeFontTheme()));
    LOG.assertTrue(SystemInfo.isWindows);
    UIDefaults defaults = UIManager.getDefaults();
    defaults.put("Tree.collapsedIcon", WindowsTreeUI.CollapsedIcon.createCollapsedIcon());
    defaults.put("Tree.expandedIcon", WindowsTreeUI.ExpandedIcon.createExpandedIcon());
  }

  @NotNull
  public String getName() {
    return NAME;
  }

  @Override public UIDefaults getDefaults() {
    final UIDefaults defaults = super.getDefaults();

    defaults.put("ToolTip.foreground", SystemColor.infoText);
    defaults.put("ToolTip.background", SystemColor.info);
    defaults.put("menu", SystemColor.control);

    defaults.put("TabbedPaneUI", AlloyIdeaTabbedPaneUI.class.getName());
    defaults.put("ComboBoxUI", AlloyIdeaComboBoxUI.class.getName());

    defaults.put("ComboBox.background", SystemColor.control);
    defaults.put("ComboBox.foreground", SystemColor.controlText);
    final Color colorUnderSelection = SystemColor.control.brighter().brighter();
    defaults.put("Table.selectedForeground", colorUnderSelection);
    defaults.put("Tree.selectedForeground", colorUnderSelection);
    defaults.put("MenuItem.acceleratorSelectionForeground", colorUnderSelection);
    return defaults;
  }

  @Override
  protected void initClassDefaults(UIDefaults defaults) {
    super.initClassDefaults(defaults);
    defaults.put("TabbedPaneUI", AlloyIdeaTabbedPaneUI.class.getName());
    defaults.put("ComboBoxUI", AlloyIdeaComboBoxUI.class.getName());
  }

  private static AlloyTheme createNativeTheme(AlloyFontTheme ftheme) {
    Color contrastColor = SystemColor.scrollbar;
    Color standardColor = SystemColor.control;
    Color desktopColor = SystemColor.desktop;
    Color selectionColor = SystemColor.control.darker().darker();
    Color rolloverColor = SystemColor.yellow.darker();
    Color highlightColor = SystemColor.textHighlight;
    return CustomThemeFactory.createTheme(
      contrastColor, standardColor, desktopColor,
      selectionColor, rolloverColor, highlightColor,
      ftheme
    );
  }
}
