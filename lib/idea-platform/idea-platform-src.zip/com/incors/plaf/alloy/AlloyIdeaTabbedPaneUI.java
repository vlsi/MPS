package com.incors.plaf.alloy;

import com.intellij.util.ui.UIUtil;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import java.awt.*;

/**
 * @author max
 */
public class AlloyIdeaTabbedPaneUI extends AlloyTabbedPaneUI {

  @SuppressWarnings({"MethodOverridesStaticMethodOfSuperclass", "UNUSED_SYMBOL"})
  public static ComponentUI createUI(JComponent tabbedpane) {
    return new AlloyIdeaTabbedPaneUI();
  }


  @Override
  protected void paintTabBackground(Graphics g, int tabPlacement, int i1, int x, int y, int width, int height, boolean isSelected) {
    if (isSelected) {
      final Graphics2D g2d = (Graphics2D) g;
      g2d.setPaint(new GradientPaint(x, y, SystemColor.white, x, y + height, SystemColor.control));
      g.fillRect(x + 1, y , width - 1, height);
    }
    else {
      g.setColor(SystemColor.control);
      g.fillRect(x, y, width, height);
    }
  }

  @Override
  protected void paintTabBorder(Graphics g, int tabPlacement, int i1, int x, int y, int width, int height, boolean isSelected) {
    super.paintTabBorder(g, tabPlacement, i1, x, y, width, height, isSelected);

    if (isSelected && tabPlacement == JTabbedPane.TOP) {
      g.setColor(SystemColor.controlLtHighlight);
      UIUtil.drawLine(g, x, y + height + 1, x + width, y + height + 1);
    }
  }
}
