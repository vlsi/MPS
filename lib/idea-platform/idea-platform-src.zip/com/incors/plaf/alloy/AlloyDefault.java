package com.incors.plaf.alloy;

import org.jetbrains.annotations.NotNull;

/**
 * @author max
 */
public class AlloyDefault extends IdeaAlloyLAF {
  public static final String NAME = "Alloy. Default Theme";

  public AlloyDefault() {
    super(new DefaultAlloyTheme(createNativeFontTheme()));
  }

  @NotNull
  public String getName() {
    return NAME;
  }
}
