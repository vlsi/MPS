package com.incors.plaf.alloy;

import com.incors.plaf.alloy.themes.acid.AcidTheme;
import org.jetbrains.annotations.NotNull;

/**
 * @author max
 */
public class AlloyAcid extends IdeaAlloyLAF {
  public static final String NAME = "Alloy. Acid Theme";

  public AlloyAcid() {
    super(new AcidTheme(createNativeFontTheme()));
  }

  @NotNull
  public String getName() {
    return NAME;
  }
}
