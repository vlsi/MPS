package com.incors.plaf.alloy;


import com.intellij.util.ui.UIUtil;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import java.awt.*;

/**
 * User: anna
 * Date: Jul 12, 2005
 */
public class AlloyIdeaComboBoxUI extends AlloyComboBoxUI {
  @SuppressWarnings({"MethodOverridesStaticMethodOfSuperclass", "UNUSED_SYMBOL"})
  public static ComponentUI createUI(JComponent tabbedpane) {
    return new AlloyIdeaComboBoxUI();
  }

  public void paintCurrentValue(Graphics g, Rectangle bounds, boolean hasFocus) {
    ListCellRenderer renderer = comboBox.getRenderer();
    Component c;

    if (hasFocus && !isPopupVisible(comboBox)) {
      c = renderer.getListCellRendererComponent(listBox,
                                                comboBox.getSelectedItem(),
                                                -1,
                                                false,
                                                false);
    }
    else {
      c = renderer.getListCellRendererComponent(listBox,
                                                comboBox.getSelectedItem(),
                                                -1,
                                                false,
                                                false);
      c.setBackground(UIUtil.getListBackground());
    }
    c.setFont(comboBox.getFont());
    if (hasFocus && !isPopupVisible(comboBox)) {
      c.setForeground(comboBox.getForeground());
      c.setBackground(comboBox.getBackground());
    }
    else {
      if (comboBox.isEnabled()) {
        c.setForeground(comboBox.getForeground());
        c.setBackground(comboBox.getBackground());
      } else {
        c.setForeground(UIUtil.getComboBoxDisabledForeground());
        c.setBackground(UIUtil.getComboBoxDisabledBackground());
      }
    }

    // Fix for 4238829: should lay out the JPanel.
    boolean shouldValidate = false;
    if (c instanceof JPanel) {
      shouldValidate = true;
    }

    currentValuePane.paintComponent(g, c, comboBox, bounds.x, bounds.y,
                                    bounds.width, bounds.height, shouldValidate);

  }
}
