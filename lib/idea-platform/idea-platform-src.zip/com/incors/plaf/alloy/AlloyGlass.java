package com.incors.plaf.alloy;

import com.incors.plaf.alloy.themes.glass.GlassTheme;
import org.jetbrains.annotations.NotNull;

/**
 * @author max
 */
public class AlloyGlass extends IdeaAlloyLAF {
  public static final String NAME = "Alloy. Glass Theme";

  public AlloyGlass() {
    super(new GlassTheme(createNativeFontTheme()));
  }

  @NotNull
  public String getName() {
    return NAME;
  }
}
