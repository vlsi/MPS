package com.incors.plaf.alloy;

import com.incors.plaf.alloy.themes.bedouin.BedouinTheme;
import org.jetbrains.annotations.NotNull;

/**
 * @author max
 */
public class AlloyBedouin extends IdeaAlloyLAF {
  public static final String NAME = "Alloy. Bedoin Theme";

  public AlloyBedouin() {
    super(new BedouinTheme(createNativeFontTheme()));
  }

  @NotNull
  public String getName() {
    return NAME;
  }
}
